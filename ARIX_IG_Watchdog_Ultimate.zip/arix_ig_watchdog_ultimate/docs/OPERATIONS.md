# Operations and recovery notes

## Backup
Stop the process or use SQLite's online backup API before copying the database.
Copy the authorized Instagram settings file separately into encrypted storage.
Do not place either file in a public web directory.

## Restart recovery
The scheduler queries rows whose state is `active` and recreates one asyncio task
per monitor. Task identity is keyed by monitor ID in the current process. Stopped
and paused rows are not scheduled. Each successful lookup is saved before it can
become a baseline for the next comparison. Failed/unknown lookups update attempt
statistics but do not replace the last successful snapshot.

## Rate limiting
The service serializes requests and applies a configurable minimum gap. This is a
best-effort local throttle, not a guarantee against platform rate limits. Avoid
multiple application replicas sharing the same account session. Instagram may
reject access at any time.

## Data deletion
User deletion is confirmation-gated in the bot. The SQLite database is local and
should also be included in the operator's retention and backup policy. Deleting
monitor data does not delete Instagram account data.

## Known operational limitations
- This is a single-process SQLite worker; horizontal scaling is not supported.
- Telegram callbacks are stateless except for per-user flow state and expire safely.
- Instagram profile fields may be absent or unavailable depending on provider access.
- Ban/unban labels describe access-state transitions, not a platform enforcement
  decision.
