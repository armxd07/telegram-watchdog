# Acceptance checklist

## Bot navigation
- [ ] `/start` sends welcome and persistent reply keyboard.
- [ ] Every reply-keyboard label opens its corresponding flow.
- [ ] Callback queries are acknowledged before handler work.
- [ ] Home and Cancel return to a safe state.
- [ ] Expired monitor IDs are rejected with an explanation.
- [ ] Long lists show previous/next controls.

## Profile lookup
- [ ] Valid username is normalized before lookup.
- [ ] Only a successful provider response is presented as a verified snapshot.
- [ ] Error state does not overwrite a prior successful snapshot.
- [ ] Card includes actual values and lookup duration.

## Monitor lifecycle
- [ ] Duplicate active monitor tuple is rejected inside a transaction.
- [ ] Startup restores active monitor rows.
- [ ] Pause and stop cancel the asyncio task.
- [ ] Resume schedules exactly one task.
- [ ] Unknown provider errors do not generate availability events.
- [ ] Numeric changes include a numeric delta.
- [ ] Missing fields are not treated as changes.

## Data and custom cards
- [ ] Custom card rows live in `custom_cards`, not event tables.
- [ ] Export contains only the requesting user's rows.
- [ ] Delete action requires confirmation.
- [ ] SQLite WAL and busy timeout are enabled.
- [ ] ZIP archive integrity is checked after packaging.

The checked status for this generated archive is documented in the delivery response.
