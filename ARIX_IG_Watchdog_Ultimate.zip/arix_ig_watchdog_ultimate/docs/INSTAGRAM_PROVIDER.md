# Instagram provider notes

The integration boundary is intentionally narrow: `lookup(username)` returns one
of `available`, `unavailable`, or `unknown`. A successful profile object is converted
to a `ProfileSnapshot`. A provider exception is classified conservatively.

The `instagrapi` library is not an official Meta API. It can break after server-side
changes and may cause account challenges. The application therefore serializes
requests, waits between requests, uses timeouts, and never treats a challenge or
rate-limit response as account unavailability. Operators should stop monitoring
when the provider requests additional verification.

The configured session must belong to an account the operator controls or is
authorized to use. Do not automate login attempts, evade checkpoints, rotate
identities to bypass restrictions, or access private profiles without permission.
The Telegram interface intentionally has no password collection form.

A successful response only means the profile was accessible through the configured
session at that observation time. A failed lookup is not an enforcement signal.
Even an explicit not-found response can have causes other than a ban. Notification
copy therefore uses "unavailable" and explicitly states uncertainty.

Fields omitted by the provider remain `None` or empty. Snapshot diffing skips
fields where either side is missing. This prevents false positive changes when
Instagram omits a statistic or profile attribute.
