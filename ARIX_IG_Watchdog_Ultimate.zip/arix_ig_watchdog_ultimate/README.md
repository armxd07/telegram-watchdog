# ARIX IG Watchdog Ultimate

A persistent Telegram monitoring application with profile lookup, change tracking,
availability/recovery watches, custom image cards, statistics, history, CSV export,
and SQLite-backed restart recovery.

## Important Instagram access limitation

Instagram does not provide a general-purpose official API for arbitrary public
personal-profile follower/following/post counts or reliable account-ban status.
This project uses an **authenticated `instagrapi` adapter** as an optional access
provider. `instagrapi` is an unofficial client and Instagram may restrict, challenge,
or change it at any time. Use only an account and session you own or are explicitly
authorized to use, follow Instagram's terms and applicable law, and keep polling
conservative. The project does not bypass login, checkpoints, private-account
permissions, rate limits, or other access controls.

A lookup error is `UNKNOWN`, never proof of a ban. The classifier only considers a
narrow set of explicit not-found/account-unavailable responses unavailable; challenge,
login, rate-limit, timeout, network, and unknown failures remain unknown. Even an
explicit unavailable response is not proof of a ban: it can mean deactivation,
username change, regional restriction, or a transient platform response. User-facing
cards say "unavailable" rather than asserting a ban.

The adapter requires an authorized Instagram session. Set `IG_SESSIONID` or provide
a supported settings file via `IG_SETTINGS_PATH`. Do **not** send Instagram
passwords or session cookies to the Telegram bot. Prefer a session settings file
created locally with instagrapi. Protect it like a password. Session ID login can
be challenged and is not guaranteed to work.

## Features

- Telegram commands and persistent reply-keyboard menu.
- Inline callback navigation, pagination, confirmations, cancel/back/home.
- Live profile lookup and generated Pillow profile cards.
- Persistent live-change, availability, and recovery monitors.
- Snapshot normalization and missing-field-safe comparisons.
- Monitor uniqueness, per-user limits, check pacing, retries/backoff.
- Separate custom-card records; custom cards never become verified events.
- SQLite transactions, schema versioning, event/snapshot/check history.
- Statistics, event filters, time dashboard, CSV and personal-data export.
- Graceful scheduler shutdown and monitor reload after restart.

## Setup (Python 3.12+)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Put the Telegram bot token in `.env`. Configure an authorized Instagram session
locally. `IG_SESSIONID` is optional if `IG_SETTINGS_PATH` points to a valid
instagrapi settings JSON. Create the settings file outside Telegram; never commit it.
Set a conservative `CHECK_SECONDS` (900 seconds or more is recommended).

```bash
python -m arix
```

## Android-friendly setup

Use Termux from its official distribution source, install Python 3.12 where
available, then clone the repository, create a virtual environment, install
requirements, edit `.env`, and run `python -m arix`. Android background execution
can be suspended by battery optimization; use a persistent server for dependable
monitoring. Do not expose `.env` or session files in shared storage.

## Docker

```bash
docker build -t arix-watchdog .
docker run -d --name arix --restart unless-stopped \
  --env-file .env -v arix-data:/app/data arix-watchdog
```

The mounted volume is required to preserve SQLite and Instagram session settings.
For Docker Compose, use the same image, `env_file: .env`, and a named volume at
`/app/data`.

## GitHub deployment

1. Create a private repository; never commit `.env`, session JSON, or database files.
2. Push the project and configure deployment secrets in the hosting provider.
3. Attach persistent storage at the configured `DATABASE_PATH` parent directory.
4. Run `python -m arix` as a long-running worker, not a short-lived web request.
5. Confirm logs and test restart recovery.

## Free hosting and uptime

Free hosts may sleep, terminate workers, or erase local files. A sleeping web service
is not a reliable monitor. Use an always-on worker and persistent disk for continuous
checks. No free-hosting provider is guaranteed to run 24/7. Polling can also be delayed
by Instagram throttling, network outages, or Telegram delivery failures.

## Commands

`/start /menu /live /monitor /banmonitor /unbanmonitor /customcard /watchlist
/stats /history /duration /refresh /pause /resume /remove /settings /status
/help /cancel`

Commands accept optional usernames/IDs where relevant; without arguments they open
the guided UI. All callbacks are routed through a central dispatcher and acknowledged.

## Monitoring semantics

- **Live**: compares successfully fetched normalized snapshots.
- **Ban**: records a transition from verified accessible to explicitly unavailable.
  It does not claim the account was banned.
- **Unban/recovery**: starts from an explicit unavailable baseline or asks for an
  acknowledged recovery-watch mode. Recovery requires a later successful lookup.
- Unknown failures do not change availability state and do not generate transitions.
- Polling timestamps are UTC. Durations are derived from persisted timestamps.
- Custom cards use manually supplied values and are stored in a separate table.

## Tests

```bash
pytest -q
```

The test suite mocks the Instagram boundary and tests database operations, classifiers,
snapshot diffs, formatting, pagination, card rendering, monitor uniqueness, restart
recovery, and handler/keyboards route coverage. A real Telegram token and authorized
Instagram session are required for external integration testing; those services are
not contacted by unit tests.

## Security and operations

- Keep bot token, session ID, and settings file private.
- Rotate a token if it is exposed. Never paste credentials into support chats.
- Restrict filesystem permissions on `.env`, settings, database, and backups.
- Do not enable verbose HTTP logging in production.
- Use `/settings` to export/delete your own data. Delete is confirmation-gated.
- SQLite is suitable for a single bot process. For multiple replicas, migrate to a
  server database and distributed scheduler before scaling horizontally.

## Architecture map

- `config.py`: environment parsing and safe bounds.
- `database.py` / `migrations.py`: SQLite schema, transactions, CRUD and migration version.
- `instagram_service.py` / `instagram_protocol.py`: authenticated provider boundary.
- `availability_classifier.py`: conservative error classification.
- `monitoring_engine.py` / `scheduler.py`: persisted monitor lifecycle and restart restoration.
- `diffing.py` / `models.py`: normalized snapshot models and safe comparisons.
- `telegram_handlers.py` / `keyboards.py` / `conversations.py`: Telegram interaction layer.
- `card_renderer.py`: common Pillow renderer for live and custom cards.
- `statistics.py` / `event_history.py` / `exporters.py`: stored metrics and exports.
- `time_utils.py` / `monitor_policy.py` / `pagination.py`: shared pure helpers.
- `security.py` / `logging_config.py`: secret hygiene helpers.
- `tests/`: unit tests with mocked provider boundaries.

The generated implementation is a functional foundation, not a certification that
Instagram's unofficial client will remain operational. The live Instagram and Telegram
acceptance checklist must be run in an operator-controlled environment.
