import pytest
from arix.statistics import dashboard,render_dashboard

@pytest.mark.asyncio
async def test_stats_derived_from_rows(db):
    await db.create_monitor(2,2,"a","live",900,5)
    data=await dashboard(db,2,"2026-01-01T00:00:00+00:00")
    assert data["active"]==1
    text=render_dashboard(data)
    assert "Active monitors: 0" not in text
    assert "Verified snapshots: 0" in text
