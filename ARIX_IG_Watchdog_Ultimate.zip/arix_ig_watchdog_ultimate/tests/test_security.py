import json
from arix.security import safe_json

def test_json_export():
    assert json.loads(safe_json({"private":"value"}))["private"]=="value"
