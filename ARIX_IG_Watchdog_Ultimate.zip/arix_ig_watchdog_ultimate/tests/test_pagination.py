def paginate(items,page,size):
    start=max(0,page)*size
    return items[start:start+size], start+size<len(items)

def test_pagination():
    items=list(range(19))
    page,more=paginate(items,0,8)
    assert page==list(range(8)) and more
    page,more=paginate(items,2,8)
    assert page==[16,17,18] and not more
