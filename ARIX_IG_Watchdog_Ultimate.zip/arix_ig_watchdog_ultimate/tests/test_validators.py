import pytest
from arix.validators import normalize_username,parse_interval,parse_nonnegative_int

@pytest.mark.parametrize("value,expected",[
 ("@Some.User","some.user"),("https://instagram.com/Hello_1/","hello_1"),
 ("simple","simple")])
def test_username(value,expected): assert normalize_username(value)==expected

@pytest.mark.parametrize("value",["","a b","..","a..b",".abc","abc.","x"*31,"https://example.com"])
def test_bad_username(value):
    with pytest.raises(ValueError): normalize_username(value)

def test_interval():
    assert parse_interval("900")==900
    with pytest.raises(ValueError): parse_interval(20)

def test_integer():
    assert parse_nonnegative_int("1,200","Followers")==1200
    with pytest.raises(ValueError): parse_nonnegative_int("-1","Posts")
