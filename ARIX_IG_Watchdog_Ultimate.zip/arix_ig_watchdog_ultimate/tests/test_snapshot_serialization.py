import json
from arix.models import ProfileSnapshot

def test_snapshot_normalization():
    snapshot=ProfileSnapshot(username="@Sample.Name",full_name="  Sample   Name ",
                             biography=" bio\\r\\nline ",followers=1)
    data=snapshot.normalized()
    assert data["username"]=="@sample.name"
    assert data["full_name"]=="Sample Name"
    assert data["biography"]=="bio\\nline"

def test_snapshot_round_trip():
    source=ProfileSnapshot(username="a",followers=12)
    loaded=ProfileSnapshot.from_dict(source.normalized())
    assert loaded.username=="a" and loaded.followers==12
