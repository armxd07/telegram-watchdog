from arix.monitor_policy import next_delay,can_poll,normalize_interval

def test_poll_delay_is_conservative():
    assert next_delay(120,0,jitter=0)==300
    assert next_delay(900,2,jitter=0)==3600

def test_poll_spacing():
    assert can_poll(None,100,30)
    assert not can_poll(90,100,30)
    assert can_poll(60,100,30)

def test_interval_clamped():
    assert normalize_interval(2)==300
    assert normalize_interval(900)==900
    assert normalize_interval(900000)==86400
