from arix.conversations import begin,current,clear,Flow

class Context:
    def __init__(self): self.user_data={}

def test_flow_state_is_scoped_and_cleared():
    context=Context()
    begin(context,Flow.USERNAME,kind="ban")
    assert current(context)["name"]==Flow.USERNAME
    assert current(context)["payload"]["kind"]=="ban"
    clear(context)
    assert current(context)=={}

def test_custom_flow_payload():
    context=Context()
    begin(context,Flow.CUSTOM_VALUE,key="biography")
    assert current(context)["payload"]["key"]=="biography"
