import pytest
from arix.availability_classifier import classify_exception
from arix.models import Availability

@pytest.mark.parametrize("message",[
 "challenge_required","checkpoint required","Too many requests",
 "login_required","Connection reset","Request timed out","forbidden",
 "random API response"])
def test_ambiguous_errors_are_unknown(message):
    assert classify_exception(Exception(message))[0]==Availability.UNKNOWN
