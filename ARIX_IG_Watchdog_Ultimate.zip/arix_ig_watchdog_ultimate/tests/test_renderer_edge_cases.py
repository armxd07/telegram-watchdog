from arix.card_renderer import render_card

def test_all_event_layouts_render():
    values={"username":"test","followers":None,"following":0,"posts":10,
            "biography":"","footer":"test"}
    for kind in ("live","change","ban","unban","custom_live","custom_ban","custom_unban","custom_change"):
        assert render_card(values,kind=kind,custom=kind.startswith("custom")).size==(1200,760)

def test_extreme_unicode_and_long_values():
    values={"username":"名"*120,"full_name":"Name"*100,
            "biography":"नमस्ते "*1000,"followers":10**18}
    assert render_card(values).size==(1200,760)
