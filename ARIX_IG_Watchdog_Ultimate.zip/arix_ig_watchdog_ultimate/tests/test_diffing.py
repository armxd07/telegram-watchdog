from arix.diffing import compare_snapshots

def test_numeric_and_text_changes(snapshot):
    old=snapshot.normalized()
    new=dict(old,followers=117,biography="new bio",posts=12)
    changes=compare_snapshots(old,new)
    assert len(changes)==2
    assert next(x for x in changes if x["field"]=="followers")["difference"]==17

def test_missing_values_are_not_changes():
    assert compare_snapshots({"followers":None},{"followers":99})==[]

def test_no_duplicate_for_equal_values(snapshot):
    assert compare_snapshots(snapshot.normalized(),snapshot.normalized())==[]
