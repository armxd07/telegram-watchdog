import pytest, json
from arix.models import iso, ProfileSnapshot

@pytest.mark.asyncio
async def test_crud_and_restart(db,tmp_path):
    await db.ensure_user(10,20)
    mid=await db.create_monitor(10,20,"sample","live",900,5)
    snap=ProfileSnapshot(username="sample",followers=7,fetched_at=iso())
    sid=await db.save_snapshot(mid,10,snap)
    await db.update_monitor(mid,10,last_success_at=snap.fetched_at,success_count=1)
    row=await db.get_monitor(mid,10)
    assert row["success_count"]==1
    assert (await db.latest_snapshot(mid))["id"]==sid
    path=db.path; await db.close()
    from arix.database import Database
    reopened=await Database(path).open()
    assert (await reopened.get_monitor(mid,10))["username"]=="sample"
    await reopened.close()

@pytest.mark.asyncio
async def test_duplicate_monitor_blocked(db):
    await db.create_monitor(1,1,"same","live",900,5)
    with pytest.raises(ValueError):
        await db.create_monitor(1,1,"same","live",900,5)

@pytest.mark.asyncio
async def test_user_limit(db):
    await db.create_monitor(1,1,"one","live",900,1)
    with pytest.raises(ValueError):
        await db.create_monitor(1,1,"two","live",900,1)

@pytest.mark.asyncio
async def test_custom_card_isolation(db):
    await db.execute("INSERT INTO custom_cards(user_id,chat_id,username,payload_json,created_at) VALUES(1,1,'x','{}',?)",(iso(),))
    assert (await db.fetchone("SELECT COUNT(*) n FROM change_events"))["n"]==0
