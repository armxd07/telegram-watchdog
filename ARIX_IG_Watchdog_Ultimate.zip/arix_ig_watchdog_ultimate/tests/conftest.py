import pytest, tempfile, os
from arix.database import Database
from arix.models import ProfileSnapshot, iso

@pytest.fixture
async def db(tmp_path):
    database=await Database(str(tmp_path/"test.sqlite3")).open()
    yield database
    await database.close()

@pytest.fixture
def snapshot():
    return ProfileSnapshot(username="sample.user",full_name="Sample User",
        biography="A bio",followers=100,following=50,posts=12,
        verified=False,is_private=False,fetched_at=iso(),duration_ms=40)
