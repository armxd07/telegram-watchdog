from arix.keyboards import MAIN_ROWS, profile_actions, settings_keyboard
from arix.telegram_handlers import register_handlers

def test_all_menu_labels_present():
    labels={x for row in MAIN_ROWS for x in row}
    assert len(labels)==13
    assert "📸 Live Profile" in labels and "⚙️ Settings" in labels

def test_callback_routes_registered():
    class FakeApp:
        def __init__(self): self.handlers=[]
        def add_handler(self,h): self.handlers.append(h)
    class Fake: pass
    app=FakeApp(); register_handlers(app,Fake())
    assert len(app.handlers)>=20

def test_keyboard_actions_have_callback_data():
    for keyboard in (profile_actions(),settings_keyboard()):
        assert keyboard.inline_keyboard
        assert all(button.callback_data for row in keyboard.inline_keyboard for button in row)
