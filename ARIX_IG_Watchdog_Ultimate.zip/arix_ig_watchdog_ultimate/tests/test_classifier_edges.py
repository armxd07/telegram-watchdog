import pytest
from arix.availability_classifier import classify_exception
from arix.models import Availability

@pytest.mark.parametrize("text",[
 "user not found","User_Not_Found","profile is unavailable",
 "this page isn't available","requested user does not exist"])
def test_explicit_unavailable_messages(text):
    assert classify_exception(Exception(text))[0]==Availability.UNAVAILABLE

@pytest.mark.parametrize("text",[
 "checkpoint required: user not found","too many requests: profile unavailable",
 "login_required: user not found","connection timeout"])
def test_restriction_and_transient_precedence(text):
    assert classify_exception(Exception(text))[0]==Availability.UNKNOWN
