# Callback and external integration test plan

Unit tests inspect registered PTB handlers and keyboard callback data. For a live
acceptance pass, create a private Telegram bot, set `TELEGRAM_BOT_TOKEN`, configure
an authorized Instagram session locally, start the process, and manually exercise:
menu navigation, lookup success/error, each monitor type, pause/resume/stop,
snapshot navigation, custom card edit/preview/save, export, deletion confirmation,
and process restart. A real Instagram account and Telegram delivery are deliberately
not contacted by automated unit tests.
