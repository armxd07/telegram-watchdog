import pytest
from arix.models import MonitorState, MonitorType

def test_monitor_enums_are_stable():
    assert MonitorState.ACTIVE.value=="active"
    assert MonitorState.PAUSED.value=="paused"
    assert MonitorState.STOPPED.value=="stopped"
    assert MonitorType.LIVE.value=="live"
    assert MonitorType.BAN.value=="ban"
    assert MonitorType.UNBAN.value=="unban"

@pytest.mark.parametrize("kind",["live","ban","unban"])
def test_supported_monitor_kinds(kind):
    assert kind in {item.value for item in MonitorType}
