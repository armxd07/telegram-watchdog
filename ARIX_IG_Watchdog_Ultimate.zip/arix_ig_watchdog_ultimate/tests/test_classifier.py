from arix.availability_classifier import classify_exception
from arix.models import Availability

def test_explicit_unavailable():
    state,code=classify_exception(Exception("User not found"))
    assert state==Availability.UNAVAILABLE

def test_rate_limit_unknown():
    state,_=classify_exception(Exception("Too many requests"))
    assert state==Availability.UNKNOWN

def test_challenge_unknown():
    state,_=classify_exception(Exception("challenge_required"))
    assert state==Availability.UNKNOWN

def test_unrecognized_unknown():
    state,_=classify_exception(RuntimeError("strange backend error"))
    assert state==Availability.UNKNOWN
