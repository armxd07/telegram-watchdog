from arix.time_utils import format_duration

def test_duration_formats():
    assert format_duration(42)=="42s"
    assert format_duration(65)=="1m 5s"
    assert format_duration(3661)=="1h 1m"
    assert format_duration(90061)=="1d 1h 1m"
    assert format_duration(None)=="—"
