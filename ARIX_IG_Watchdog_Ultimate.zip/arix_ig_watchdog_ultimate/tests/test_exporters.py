import json
from arix.exporters import json_export,csv_rows,redact_runtime_settings

def test_json_export_roundtrip():
    assert json.loads(json_export({"name":"sample"}))["name"]=="sample"

def test_csv_export():
    assert "username" in csv_rows(["username"],[["arix"]])

def test_settings_redaction():
    safe=redact_runtime_settings({"bot_token":"secret","theme":"blue"})
    assert safe["bot_token"]=="[REDACTED]" and safe["theme"]=="blue"
