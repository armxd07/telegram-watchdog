import pytest
from types import SimpleNamespace
from arix.monitoring_engine import MonitoringEngine
from arix.models import Availability, ProfileSnapshot, iso

class FakeIG:
    def __init__(self,result): self.result=result
    async def lookup(self,username): return self.result

class FakeBot:
    def __init__(self): self.messages=[]
    async def send_message(self,**kwargs): self.messages.append(kwargs)

@pytest.mark.asyncio
async def test_unknown_does_not_emit_event(db):
    mid=await db.create_monitor(1,1,"x","ban",300,5)
    await db.update_monitor(mid,1,last_success_at=iso(),success_count=1)
    engine=MonitoringEngine(db,FakeIG(SimpleNamespace(availability=Availability.UNKNOWN,
        error_code="rate_limit",duration_ms=4,snapshot=None)),FakeBot(),
        SimpleNamespace(max_monitors_per_user=5))
    row=await db.get_monitor(mid,1)
    await engine.check(dict(row))
    assert (await db.fetchone("SELECT COUNT(*) n FROM availability_events"))["n"]==0

@pytest.mark.asyncio
async def test_live_change_event(db):
    mid=await db.create_monitor(1,1,"x","live",300,5)
    first=ProfileSnapshot(username="x",followers=10,fetched_at=iso())
    await db.save_snapshot(mid,1,first)
    await db.update_monitor(mid,1,last_success_at=first.fetched_at,success_count=1)
    second=ProfileSnapshot(username="x",followers=14,fetched_at=iso())
    bot=FakeBot()
    engine=MonitoringEngine(db,FakeIG(SimpleNamespace(availability=Availability.AVAILABLE,
        snapshot=second,error_code="",duration_ms=12)),bot,SimpleNamespace(max_monitors_per_user=5))
    await engine.check(dict(await db.get_monitor(mid,1)))
    row=await db.fetchone("SELECT * FROM change_events")
    assert row["difference"]==4
    assert bot.messages

@pytest.mark.asyncio
async def test_stop_cancels_task(db):
    mid=await db.create_monitor(1,1,"x","live",300,5)
    engine=MonitoringEngine(db,FakeIG(None),FakeBot(),SimpleNamespace())
    engine.tasks[mid]=__import__("asyncio").create_task(__import__("asyncio").sleep(60))
    await engine.stop(mid,1)
    assert engine.tasks[mid].cancelled() or mid not in engine.tasks
