from arix.card_renderer import render_card, compact_number

def test_card_renders_long_text_and_missing_avatar():
    image=render_card({"username":"u"*80,"biography":"bio "*1000,
        "followers":999999999,"following":None,"posts":4},kind="live")
    assert image.size==(1200,760)

def test_number_format():
    assert compact_number(1000)=="1,000"
    assert compact_number(None)=="—"
