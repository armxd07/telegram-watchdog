import pytest
from arix.pagination import paginate,clamp_page

def test_empty_page():
    page=paginate([],0,10)
    assert page.items==[] and not page.has_next and not page.has_previous

def test_middle_page():
    page=paginate(list(range(21)),1,10)
    assert page.items==list(range(10,20))
    assert page.has_previous and page.has_next

def test_clamp_page():
    assert clamp_page(100,21,10)==2
    assert clamp_page(-2,21,10)==0

def test_invalid_size():
    with pytest.raises(ValueError): paginate([1],0,0)
