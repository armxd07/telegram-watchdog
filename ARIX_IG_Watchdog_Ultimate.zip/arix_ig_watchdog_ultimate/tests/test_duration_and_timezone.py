from datetime import datetime, timezone
from arix.time_utils import parse_ts, elapsed, display_ts, format_duration

def test_utc_timestamp_parsing():
    parsed=parse_ts("2026-01-01T00:00:00Z")
    assert parsed.tzinfo==timezone.utc

def test_elapsed_from_stored_timestamps():
    assert elapsed("2026-01-01T00:00:00+00:00","2026-01-01T00:01:00+00:00")==60

def test_timezone_display():
    result=display_ts("2026-01-01T00:00:00+00:00","Asia/Kolkata")
    assert "05:30:00" in result

def test_negative_duration_clamped():
    assert format_duration(-4)=="0s"
