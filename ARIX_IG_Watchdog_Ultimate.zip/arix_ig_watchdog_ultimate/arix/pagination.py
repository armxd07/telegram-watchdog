"""Pure pagination utilities shared by lists and history screens."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Page:
    items: list
    page: int
    page_size: int
    has_previous: bool
    has_next: bool
    total: int | None = None

def paginate(items, page=0, page_size=8):
    if page_size < 1:
        raise ValueError("page_size must be positive")
    page=max(0,int(page))
    start=page*page_size
    subset=list(items[start:start+page_size])
    return Page(subset,page,page_size,page>0,start+page_size<len(items),len(items))

def clamp_page(page,total,page_size):
    last=max(0,(max(0,total)-1)//page_size)
    return min(max(0,int(page)),last)
