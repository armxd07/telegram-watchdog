import json
from .time_utils import elapsed

TRACKED_FIELDS = ("followers","following","posts","full_name","biography",
                  "profile_pic_url","verified","is_private")

def compare_snapshots(previous, current):
    if not previous or not current:
        return []
    old = previous if isinstance(previous, dict) else previous.normalized()
    new = current if isinstance(current, dict) else current.normalized()
    changes = []
    for field in TRACKED_FIELDS:
        before, after = old.get(field), new.get(field)
        if before is None or after is None:
            continue
        if before != after:
            diff = after - before if isinstance(before, (int,float)) and isinstance(after,(int,float)) else None
            changes.append({"field":field,"old":before,"new":after,"difference":diff})
    return changes

def decode_snapshot(row):
    return json.loads(row["data_json"]) if row else None
