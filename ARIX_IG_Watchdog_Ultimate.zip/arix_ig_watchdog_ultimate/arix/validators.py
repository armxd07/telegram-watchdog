import re

USERNAME_RE = re.compile(r"^[A-Za-z0-9._]{1,30}$")

def normalize_username(value: str) -> str:
    value = (value or "").strip()
    value = re.sub(r"^https?://(www\.)?instagram\.com/", "", value, flags=re.I)
    value = value.split("?", 1)[0].strip("/")
    value = value.lstrip("@")
    if not USERNAME_RE.fullmatch(value):
        raise ValueError("Enter a valid Instagram username (1–30 letters, digits, dots or underscores).")
    if value.startswith(".") or value.endswith(".") or ".." in value:
        raise ValueError("Username cannot start/end with a dot or contain consecutive dots.")
    return value.lower()

def parse_nonnegative_int(value, field):
    try:
        number = int(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        raise ValueError(f"{field} must be a whole number.")
    if number < 0:
        raise ValueError(f"{field} cannot be negative.")
    return number

def parse_interval(value, minimum=300, maximum=86400):
    try:
        seconds = int(value)
    except (TypeError, ValueError):
        raise ValueError("Interval must be a number of seconds.")
    if not minimum <= seconds <= maximum:
        raise ValueError(f"Interval must be between {minimum} and {maximum} seconds.")
    return seconds
