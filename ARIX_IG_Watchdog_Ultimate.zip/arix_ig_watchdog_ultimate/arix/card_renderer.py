from PIL import Image, ImageDraw, ImageFont, ImageOps
from io import BytesIO
import aiohttp, textwrap, os, math

W,H = 1200,760
NAVY=(7,13,29); PANEL=(15,27,49); BLUE=(35,145,255); WHITE=(241,246,255); MUTED=(151,169,194)

def font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if os.path.exists(path): return ImageFont.truetype(path,size)
    return ImageFont.load_default()

def compact_number(value):
    if value is None: return "—"
    try: return f"{int(value):,}"
    except (TypeError,ValueError): return str(value)

def _gradient():
    image=Image.new("RGB",(W,H))
    px=image.load()
    for y in range(H):
        for x in range(W):
            t=(x/W)*.55+(y/H)*.45
            px[x,y]=tuple(int(NAVY[i]*(1-t)+((14,35,68)[i])*t) for i in range(3))
    return image

def _avatar(image, avatar):
    draw=ImageDraw.Draw(image)
    x,y,r=90,150,76
    if avatar:
        try:
            with Image.open(BytesIO(avatar)) as src:
                pic=ImageOps.fit(src.convert("RGB"),(r*2,r*2))
            mask=Image.new("L",(r*2,r*2),0)
            ImageDraw.Draw(mask).ellipse((0,0,r*2-1,r*2-1),fill=255)
            image.paste(pic,(x-r,y-r),mask)
        except Exception:
            draw.ellipse((x-r,y-r,x+r,y+r),fill=PANEL,outline=BLUE,width=5)
    else:
        draw.ellipse((x-r,y-r,x+r,y+r),fill=PANEL,outline=BLUE,width=5)
        draw.text((x-22,y-25),"IG",font=font(38,True),fill=BLUE)

def render_card(data, kind="live", avatar=None, custom=False):
    image=_gradient(); draw=ImageDraw.Draw(image)
    draw.rounded_rectangle((34,30,W-34,H-30),radius=34,outline=(37,69,110),width=2)
    draw.text((80,65),"ARIX  /  INSTAGRAM WATCHDOG",font=font(22,True),fill=BLUE)
    titles={"live":"LIVE PROFILE","change":"PROFILE CHANGE","ban":"GOING INTO VOID",
            "unban":"BACK FROM VOID","custom_live":"CUSTOM PROFILE CARD",
            "custom_ban":"CUSTOM BAN CARD","custom_unban":"CUSTOM UNBAN CARD",
            "custom_change":"CUSTOM CHANGE CARD"}
    draw.text((80,105),titles.get(kind,"PROFILE CARD"),font=font(34,True),fill=WHITE)
    _avatar(image,avatar); draw=ImageDraw.Draw(image)
    username=str(data.get("username") or "unknown")
    draw.text((205,145),"@"+username[:42],font=font(35,True),fill=WHITE)
    name=str(data.get("full_name") or data.get("display_name") or "")
    draw.text((205,195),name[:48],font=font(22),fill=MUTED)
    stats=[("FOLLOWERS",data.get("followers")),("FOLLOWING",data.get("following")),("POSTS",data.get("posts"))]
    for i,(label,value) in enumerate(stats):
        x=80+i*355
        draw.rounded_rectangle((x,285,x+320,405),radius=20,fill=PANEL,outline=(35,65,102),width=2)
        draw.text((x+24,310),label,font=font(18,True),fill=MUTED)
        draw.text((x+24,345),compact_number(value),font=font(34,True),fill=WHITE)
    bio=str(data.get("biography") or "")
    draw.text((80,445),"BIOGRAPHY",font=font(18,True),fill=BLUE)
    lines=textwrap.wrap(bio.replace("\n"," "),width=95)[:3]
    for i,line in enumerate(lines):
        draw.text((80,478+i*31),line,font=font(20),fill=WHITE)
    footer=str(data.get("footer") or data.get("event_timestamp") or data.get("fetched_at") or "")
    draw.text((80,650),footer[:95],font=font(17),fill=MUTED)
    draw.text((W-310,650),("CUSTOM VALUES" if custom else "VERIFIED LOOKUP" if kind=="live" else "MONITOR EVENT"),
              font=font(15,True),fill=BLUE)
    return image

async def fetch_avatar(url, timeout=10):
    if not url: return None
    try:
        timeout_cfg=aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_cfg) as session:
            async with session.get(url) as response:
                if response.status==200: return await response.read()
    except Exception:
        return None
    return None

def save_card(data, path, kind="live", avatar=None, custom=False):
    image=render_card(data,kind,avatar,custom)
    os.makedirs(os.path.dirname(path) or ".",exist_ok=True)
    image.save(path,"PNG",optimize=True)
    return path
