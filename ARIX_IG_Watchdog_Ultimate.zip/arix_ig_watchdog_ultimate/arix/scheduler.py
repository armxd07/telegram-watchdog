class Scheduler:
    """Thin lifecycle facade; monitor loops are owned by MonitoringEngine."""
    def __init__(self, engine):
        self.engine=engine
    async def start(self):
        await self.engine.start()
    async def stop(self):
        await self.engine.shutdown()
