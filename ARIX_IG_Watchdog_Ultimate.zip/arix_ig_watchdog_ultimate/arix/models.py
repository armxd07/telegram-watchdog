from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

def utcnow():
    return datetime.now(timezone.utc)

def iso(dt=None):
    return (dt or utcnow()).astimezone(timezone.utc).isoformat()

class MonitorType(StrEnum):
    LIVE = "live"
    BAN = "ban"
    UNBAN = "unban"

class MonitorState(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"
    STOPPED = "stopped"

class Availability(StrEnum):
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"
    UNKNOWN = "unknown"

@dataclass
class ProfileSnapshot:
    username: str
    user_id: str | None = None
    full_name: str = ""
    biography: str = ""
    followers: int | None = None
    following: int | None = None
    posts: int | None = None
    profile_pic_url: str | None = None
    verified: bool | None = None
    is_private: bool | None = None
    fetched_at: str = ""
    duration_ms: int = 0
    source: str = "instagram_authorized_session"

    def normalized(self):
        data = asdict(self)
        data["username"] = self.username.strip().lstrip("@").lower()
        data["full_name"] = " ".join(self.full_name.split())
        data["biography"] = self.biography.replace("\r\n", "\n").strip()
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]):
        allowed = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in data.items() if k in allowed})

@dataclass
class LookupResult:
    availability: Availability
    snapshot: ProfileSnapshot | None = None
    error_code: str = ""
    error_message: str = ""
    duration_ms: int = 0
