from enum import StrEnum
class Flow(StrEnum):
    IDLE="idle"
    USERNAME="username"
    INTERVAL="interval"
    CUSTOM_FIELD="custom_field"
    CUSTOM_VALUE="custom_value"
    FILTER="filter"
    TIMEZONE="timezone"
    CONFIRM="confirm"

# Per-user flow state is held in PTB user_data, never in a process-global user map.
def begin(context, flow, **payload):
    context.user_data["flow"]={"name":str(flow),"payload":payload}
def current(context):
    return context.user_data.get("flow",{})
def clear(context):
    context.user_data.pop("flow",None)
