import asyncio, json, logging, time
from pathlib import Path
from .models import ProfileSnapshot, LookupResult, Availability, iso
from .availability_classifier import classify_exception

log = logging.getLogger(__name__)

class InstagramService:
    """Authorized-session adapter. Never accepts Instagram credentials from Telegram."""
    def __init__(self, config):
        self.config = config
        self.client = None
        self._lock = asyncio.Lock()
        self._last_request = 0.0

    async def start(self):
        from instagrapi import Client
        self.client = Client()
        self.client.delay_range = [1, 2]
        settings = Path(self.config.ig_settings_path)
        if settings.exists():
            self.client.load_settings(str(settings))
        elif self.config.ig_sessionid:
            self.client.login_by_sessionid(self.config.ig_sessionid)
        else:
            log.warning("No Instagram session configured; profile lookups will be unavailable.")
            return
        # Verify that the configured session is accepted, without logging secrets.
        await asyncio.to_thread(self.client.account_info)
        if self.config.ig_sessionid and not settings.exists():
            settings.parent.mkdir(parents=True, exist_ok=True)
            self.client.dump_settings(str(settings))

    async def lookup(self, username):
        started = time.monotonic()
        async with self._lock:
            wait = self.config.ig_min_request_gap - (time.monotonic() - self._last_request)
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_request = time.monotonic()
            try:
                if self.client is None:
                    return LookupResult(Availability.UNKNOWN, error_code="not_configured",
                                        error_message="Instagram authorized session is not configured.")
                user_id = await asyncio.wait_for(
                    asyncio.to_thread(self.client.user_id_from_username, username),
                    timeout=self.config.ig_request_timeout)
                info = await asyncio.wait_for(
                    asyncio.to_thread(self.client.user_info, user_id),
                    timeout=self.config.ig_request_timeout)
                duration = int((time.monotonic() - started) * 1000)
                pic = getattr(info, "profile_pic_url_hd", None) or getattr(info, "profile_pic_url", None)
                snapshot = ProfileSnapshot(
                    username=getattr(info, "username", username),
                    user_id=str(getattr(info, "pk", user_id)),
                    full_name=getattr(info, "full_name", "") or "",
                    biography=getattr(info, "biography", "") or "",
                    followers=getattr(info, "follower_count", None),
                    following=getattr(info, "following_count", None),
                    posts=getattr(info, "media_count", None),
                    profile_pic_url=str(pic) if pic else None,
                    verified=getattr(info, "is_verified", None),
                    is_private=getattr(info, "is_private", None),
                    fetched_at=iso(), duration_ms=duration)
                return LookupResult(Availability.AVAILABLE, snapshot, duration_ms=duration)
            except Exception as exc:
                state, code = classify_exception(exc)
                duration = int((time.monotonic() - started) * 1000)
                log.info("Instagram lookup failed (%s)", code)
                return LookupResult(state, error_code=code,
                                    error_message=f"{type(exc).__name__}: {str(exc)[:180]}",
                                    duration_ms=duration)

    async def close(self):
        self.client = None
