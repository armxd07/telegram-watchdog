import asyncio, json, logging
from datetime import datetime, timezone
from .models import Availability, iso, MonitorType
from .diffing import compare_snapshots, decode_snapshot
from .time_utils import elapsed

log=logging.getLogger(__name__)

class MonitoringEngine:
    def __init__(self, db, instagram, bot, config):
        self.db,self.instagram,self.bot,self.config=db,instagram,bot,config
        self.tasks={}
        self.stopping=False

    async def start(self):
        rows=await self.db.fetchall("SELECT * FROM monitors WHERE state='active'")
        for row in rows: self.schedule(dict(row))

    def schedule(self, monitor):
        mid=monitor["id"]
        task=self.tasks.get(mid)
        if task and not task.done(): return
        self.tasks[mid]=asyncio.create_task(self._run(mid),name=f"monitor-{mid}")

    async def _run(self, monitor_id):
        while not self.stopping:
            monitor=await self.db.fetchone("SELECT * FROM monitors WHERE id=?",(monitor_id,))
            if not monitor or monitor["state"]!="active": break
            try: await self.check(dict(monitor))
            except asyncio.CancelledError: raise
            except Exception: log.exception("Monitor check failed id=%s",monitor_id)
            monitor=await self.db.fetchone("SELECT interval_seconds,state FROM monitors WHERE id=?",(monitor_id,))
            if not monitor or monitor["state"]!="active": break
            await asyncio.sleep(max(30,int(monitor["interval_seconds"])))
        self.tasks.pop(monitor_id,None)

    async def check(self, monitor):
        mid,uid,chat,username=monitor["id"],monitor["user_id"],monitor["chat_id"],monitor["username"]
        result=await self.instagram.lookup(username)
        await self.db.add_attempt(mid,uid,username,result.availability.value,result.error_code,result.duration_ms)
        await self.db.update_monitor(mid,uid,last_check_at=iso(),last_duration_ms=result.duration_ms)
        if result.availability==Availability.UNKNOWN:
            await self.db.update_monitor(mid,uid,failure_count=monitor["failure_count"]+1)
            return
        if result.availability==Availability.AVAILABLE and result.snapshot:
            snap=result.snapshot
            sid=await self.db.save_snapshot(mid,uid,snap)
            oldrow=await self.db.latest_snapshot(mid)
            # latest_snapshot is current; fetch the preceding record explicitly.
            prevrow=await self.db.previous_snapshot(mid)
            previous=decode_snapshot(prevrow)
            previous_success=monitor.get("last_success_at")
            await self.db.update_monitor(mid,uid,last_success_at=snap.fetched_at,
                success_count=monitor["success_count"]+1,failure_count=0)
            if monitor["kind"]==MonitorType.LIVE:
                changes=compare_snapshots(previous,snap)
                for change in changes:
                    duration=elapsed(previous_success,snap.fetched_at)
                    event_id=await self.db.add_change(mid,uid,username,change["field"],
                        change["old"],change["new"],change["difference"],previous_success,duration)
                    await self.db.update_monitor(mid,uid,last_change_at=snap.fetched_at)
                    await self._notify(chat,self._change_text(username,change,event_id,duration))
            elif monitor["kind"]==MonitorType.UNBAN and monitor.get("first_unavailable_at"):
                event_id=await self.db.add_availability_event(mid,uid,username,"recovered",sid,
                    {"first_unavailable_at":monitor["first_unavailable_at"],"snapshot":snap.normalized()})
                duration=elapsed(monitor["first_unavailable_at"],snap.fetched_at)
                await self._notify(chat,f"🟦 BACK FROM VOID\n@{username}\nDisplay name: {snap.full_name}\n"
                    f"Followers: {snap.followers}\nFollowing: {snap.following}\nPosts: {snap.posts}\n"
                    f"Unavailable duration: {duration}s\nRecovery event: #{event_id}")
                await self.db.update_monitor(mid,uid,first_unavailable_at=None,last_unavailable_at=None)
        elif result.availability==Availability.UNAVAILABLE:
            if monitor["kind"]==MonitorType.BAN and monitor.get("last_success_at"):
                if not monitor.get("first_unavailable_at"):
                    await self.db.update_monitor(mid,uid,first_unavailable_at=iso(),last_unavailable_at=iso())
                    sidrow=await self.db.latest_snapshot(mid)
                    sid=sidrow["id"] if sidrow else None
                    details={"last_success_at":monitor["last_success_at"],"snapshot":decode_snapshot(sidrow)}
                    event_id=await self.db.add_availability_event(mid,uid,username,"unavailable",sid,details)
                    await self._notify(chat,f"⚫ GOING INTO VOID\n@{username}\n"
                        f"Last verified access: {monitor['last_success_at']}\n"
                        f"First unavailable observation: {iso()}\n"
                        f"Event #{event_id}\nThis does not prove an Instagram ban.")
            elif monitor["kind"]==MonitorType.UNBAN:
                if not monitor.get("first_unavailable_at"):
                    await self.db.update_monitor(mid,uid,first_unavailable_at=iso(),last_unavailable_at=iso())
                else:
                    await self.db.update_monitor(mid,uid,last_unavailable_at=iso())

    async def _notify(self, chat_id, text):
        try: await self.bot.send_message(chat_id=chat_id,text=text)
        except Exception: log.warning("Could not deliver monitor notification to chat %s",chat_id)

    def _change_text(self, username, change, event_id, duration):
        diff=f"\nDifference: {change['difference']:+,}" if change["difference"] is not None else ""
        return (f"🔔 @{username} — {change['field']} changed\n"
                f"Previous: {change['old']}\nNew: {change['new']}{diff}\n"
                f"Detected: {iso()}\nTime since prior successful snapshot: {duration}s\nEvent #{event_id}")

    async def pause(self, monitor_id, user_id):
        await self.db.update_monitor(monitor_id,user_id,state="paused")
        task=self.tasks.pop(monitor_id,None)
        if task: task.cancel()

    async def resume(self, monitor_id, user_id):
        await self.db.update_monitor(monitor_id,user_id,state="active")
        row=await self.db.get_monitor(monitor_id,user_id)
        if row: self.schedule(dict(row))

    async def stop(self, monitor_id, user_id):
        await self.db.update_monitor(monitor_id,user_id,state="stopped")
        task=self.tasks.pop(monitor_id,None)
        if task: task.cancel()

    async def refresh(self, monitor_id, user_id):
        row=await self.db.get_monitor(monitor_id,user_id)
        if not row: raise ValueError("Monitor not found.")
        await self.check(dict(row))

    async def shutdown(self):
        self.stopping=True
        tasks=list(self.tasks.values())
        for task in tasks: task.cancel()
        if tasks: await asyncio.gather(*tasks,return_exceptions=True)
        self.tasks.clear()
