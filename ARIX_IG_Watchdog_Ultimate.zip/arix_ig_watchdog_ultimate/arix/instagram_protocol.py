"""Provider contract used to keep Telegram and monitoring code provider-agnostic."""
from typing import Protocol
from .models import LookupResult

class ProfileProvider(Protocol):
    async def start(self) -> None: ...
    async def lookup(self, username: str) -> LookupResult: ...
    async def close(self) -> None: ...

class ProviderUnavailable(RuntimeError):
    """Raised only when the provider is not configured, never interpreted as a ban."""

def public_profile_url(username: str) -> str:
    from urllib.parse import quote
    return "https://www.instagram.com/" + quote(username, safe="._") + "/"
