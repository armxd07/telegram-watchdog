import logging
import os

class SecretFilter(logging.Filter):
    def filter(self, record):
        message = record.getMessage()
        for key in ("TELEGRAM_BOT_TOKEN", "IG_SESSIONID", "password", "sessionid"):
            value = os.getenv(key, "")
            if value and len(value) > 4:
                message = message.replace(value, "[REDACTED]")
        record.msg, record.args = message, ()
        return True

def configure_logging(level="INFO"):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    for handler in logging.getLogger().handlers:
        handler.addFilter(SecretFilter())
