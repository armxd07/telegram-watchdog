from .models import Availability

UNAVAILABLE_MARKERS = (
    "user not found", "user_not_found", "account not found",
    "profile isn't available", "profile is unavailable",
    "this page isn't available", "requested user does not exist",
)
UNKNOWN_MARKERS = (
    "challenge", "checkpoint", "login_required", "login required",
    "rate limit", "too many requests", "please wait", "timed out",
    "timeout", "connection", "network", "private", "forbidden",
    "unauthorized", "feedback_required", "suspended", "unknown",
)

def classify_exception(exc):
    text = f"{type(exc).__name__}: {exc}".lower()
    if any(marker in text for marker in UNKNOWN_MARKERS):
        return Availability.UNKNOWN, "transient_or_restricted"
    if any(marker in text for marker in UNAVAILABLE_MARKERS):
        return Availability.UNAVAILABLE, "explicit_unavailable"
    return Availability.UNKNOWN, "unclassified_error"

def classify_lookup_success(snapshot):
    return Availability.AVAILABLE if snapshot else Availability.UNKNOWN
