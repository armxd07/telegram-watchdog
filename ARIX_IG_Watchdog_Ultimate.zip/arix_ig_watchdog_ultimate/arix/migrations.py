"""Schema migration helpers.

The initial schema is idempotent and tracked in schema_migrations. Future changes
must be appended as numbered functions; never rewrite user monitoring history.
"""
from .models import iso

async def current_version(db):
    row=await db.fetchone("SELECT MAX(version) version FROM schema_migrations")
    return row["version"] or 0

async def apply_migrations(db):
    version=await current_version(db)
    if version < 1:
        await db.execute("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(1,?)",(iso(),))
    return await current_version(db)

async def migration_status(db):
    rows=await db.fetchall("SELECT version,applied_at FROM schema_migrations ORDER BY version")
    return [dict(row) for row in rows]
