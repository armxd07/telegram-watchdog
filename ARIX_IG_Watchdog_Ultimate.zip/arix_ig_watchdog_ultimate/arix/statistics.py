from .time_utils import elapsed, format_duration
async def dashboard(db,user_id,started_at):
    counts=await db.counts(user_id)
    counts["uptime_seconds"]=elapsed(started_at)
    counts["uptime"]=format_duration(counts["uptime_seconds"])
    return counts

def render_dashboard(data):
    kinds=data["by_kind"]
    return ("📊 Statistics Dashboard\n"
        f"Active monitors: {data['active']}\nLive: {kinds.get('live',0)}\n"
        f"Ban: {kinds.get('ban',0)}\nUnban: {kinds.get('unban',0)}\n"
        f"Paused: {data['paused']}\nVerified snapshots: {data['snapshots']}\n"
        f"Detected changes: {data['changes']}\nAvailability transitions: {data['transitions']}\n"
        f"Lookup attempts: {data['attempts']}\nSuccessful lookups: {data['successes']}\n"
        f"Failed/unknown: {data['failures']}\nAverage lookup: {data['avg_ms']} ms\n"
        f"Last check: {data['last_check'] or '—'}\nUptime: {data['uptime']}")
