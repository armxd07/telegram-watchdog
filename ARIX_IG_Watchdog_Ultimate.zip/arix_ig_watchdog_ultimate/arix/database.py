import aiosqlite, json
from pathlib import Path
from .models import iso

SCHEMA_VERSION = 1
SCHEMA = '''
CREATE TABLE IF NOT EXISTS users(
 user_id INTEGER PRIMARY KEY, chat_id INTEGER NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS monitors(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
 username TEXT NOT NULL, kind TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'active',
 interval_seconds INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 last_success_at TEXT, last_check_at TEXT, last_change_at TEXT,
 first_unavailable_at TEXT, last_unavailable_at TEXT, unavailable_snapshot_id INTEGER,
 success_count INTEGER NOT NULL DEFAULT 0, failure_count INTEGER NOT NULL DEFAULT 0,
 last_duration_ms INTEGER NOT NULL DEFAULT 0, UNIQUE(user_id, username, kind, state)
);
CREATE INDEX IF NOT EXISTS idx_monitors_owner ON monitors(user_id, state);
CREATE INDEX IF NOT EXISTS idx_monitors_due ON monitors(state, last_check_at);
CREATE TABLE IF NOT EXISTS snapshots(
 id INTEGER PRIMARY KEY AUTOINCREMENT, monitor_id INTEGER, user_id INTEGER NOT NULL,
 username TEXT NOT NULL, data_json TEXT NOT NULL, fetched_at TEXT NOT NULL, duration_ms INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_snapshots_monitor ON snapshots(monitor_id, fetched_at);
CREATE TABLE IF NOT EXISTS change_events(
 id INTEGER PRIMARY KEY AUTOINCREMENT, monitor_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 username TEXT NOT NULL, field TEXT NOT NULL, old_value TEXT, new_value TEXT,
 difference REAL, created_at TEXT NOT NULL, previous_success_at TEXT, duration_seconds INTEGER);
CREATE TABLE IF NOT EXISTS availability_events(
 id INTEGER PRIMARY KEY AUTOINCREMENT, monitor_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 username TEXT NOT NULL, event_type TEXT NOT NULL, snapshot_id INTEGER, created_at TEXT NOT NULL,
 details_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS custom_cards(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
 username TEXT NOT NULL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL, image_path TEXT);
CREATE TABLE IF NOT EXISTS settings(
 user_id INTEGER PRIMARY KEY, data_json TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS check_attempts(
 id INTEGER PRIMARY KEY AUTOINCREMENT, monitor_id INTEGER, user_id INTEGER NOT NULL,
 username TEXT NOT NULL, state TEXT NOT NULL, error_code TEXT, duration_ms INTEGER NOT NULL,
 checked_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_attempts_owner ON check_attempts(user_id, checked_at);
CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
'''

class Database:
    def __init__(self, path):
        self.path = path
        self.db = None

    async def open(self):
        Path(self.path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
        self.db = await aiosqlite.connect(self.path)
        self.db.row_factory = aiosqlite.Row
        await self.db.execute("PRAGMA journal_mode=WAL")
        await self.db.execute("PRAGMA foreign_keys=ON")
        await self.db.execute("PRAGMA busy_timeout=5000")
        await self.db.executescript(SCHEMA)
        await self.db.execute("INSERT OR IGNORE INTO schema_migrations VALUES(?,?)",
                              (SCHEMA_VERSION, iso()))
        await self.db.commit()
        return self

    async def close(self):
        if self.db:
            await self.db.close()
            self.db = None

    async def execute(self, sql, args=()):
        async with self.db.execute(sql, args) as cur:
            await self.db.commit()
            return cur.lastrowid

    async def fetchone(self, sql, args=()):
        async with self.db.execute(sql, args) as cur:
            return await cur.fetchone()

    async def fetchall(self, sql, args=()):
        async with self.db.execute(sql, args) as cur:
            return await cur.fetchall()

    async def ensure_user(self, user_id, chat_id):
        await self.execute("INSERT INTO users(user_id,chat_id,created_at) VALUES(?,?,?) "
                           "ON CONFLICT(user_id) DO UPDATE SET chat_id=excluded.chat_id",
                           (user_id, chat_id, iso()))

    async def create_monitor(self, user_id, chat_id, username, kind, interval_seconds, limit):
        async with self.db.execute("BEGIN IMMEDIATE"):
            row = await self.fetchone("SELECT COUNT(*) n FROM monitors WHERE user_id=? AND state!='stopped'",
                                      (user_id,))
            if row["n"] >= limit:
                raise ValueError(f"Monitor limit reached ({limit}).")
            existing = await self.fetchone(
                "SELECT id FROM monitors WHERE user_id=? AND username=? AND kind=? AND state!='stopped'",
                (user_id, username, kind))
            if existing:
                raise ValueError("This monitor already exists.")
            now = iso()
            cur = await self.db.execute(
                "INSERT INTO monitors(user_id,chat_id,username,kind,state,interval_seconds,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (user_id, chat_id, username, kind, "active", interval_seconds, now, now))
            monitor_id = cur.lastrowid
            await self.db.commit()
            return monitor_id

    async def get_monitor(self, monitor_id, user_id=None):
        sql, args = "SELECT * FROM monitors WHERE id=?", [monitor_id]
        if user_id is not None:
            sql += " AND user_id=?"; args.append(user_id)
        return await self.fetchone(sql, args)

    async def list_monitors(self, user_id, active_only=False, limit=100, offset=0):
        sql = "SELECT * FROM monitors WHERE user_id=?"
        args = [user_id]
        if active_only:
            sql += " AND state!='stopped'"
        sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        args += [limit, offset]
        return await self.fetchall(sql, args)

    async def update_monitor(self, monitor_id, user_id, **fields):
        allowed = {"state","interval_seconds","last_success_at","last_check_at","last_change_at",
                   "first_unavailable_at","last_unavailable_at","unavailable_snapshot_id",
                   "success_count","failure_count","last_duration_ms"}
        fields = {k:v for k,v in fields.items() if k in allowed}
        if not fields: return
        fields["updated_at"] = iso()
        sql = "UPDATE monitors SET " + ",".join(f"{k}=?" for k in fields) + " WHERE id=? AND user_id=?"
        await self.execute(sql, (*fields.values(), monitor_id, user_id))

    async def save_snapshot(self, monitor_id, user_id, snapshot):
        data = snapshot.normalized()
        cur = await self.db.execute(
            "INSERT INTO snapshots(monitor_id,user_id,username,data_json,fetched_at,duration_ms) VALUES(?,?,?,?,?,?)",
            (monitor_id,user_id,snapshot.username,json.dumps(data,ensure_ascii=False),snapshot.fetched_at,snapshot.duration_ms))
        await self.db.commit()
        return cur.lastrowid

    async def latest_snapshot(self, monitor_id):
        row = await self.fetchone("SELECT * FROM snapshots WHERE monitor_id=? ORDER BY id DESC LIMIT 1",
                                  (monitor_id,))
        return dict(row) if row else None

    async def previous_snapshot(self, monitor_id):
        row = await self.fetchone("SELECT * FROM snapshots WHERE monitor_id=? ORDER BY id DESC LIMIT 1 OFFSET 1",
                                  (monitor_id,))
        return dict(row) if row else None

    async def snapshot_by_id(self, snapshot_id):
        row = await self.fetchone("SELECT * FROM snapshots WHERE id=?", (snapshot_id,))
        return dict(row) if row else None

    async def add_change(self, monitor_id, user_id, username, field, old, new, diff,
                         previous_success_at, duration_seconds):
        return await self.execute(
            "INSERT INTO change_events(monitor_id,user_id,username,field,old_value,new_value,difference,created_at,previous_success_at,duration_seconds) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)",
            (monitor_id,user_id,username,field,json.dumps(old,ensure_ascii=False),
             json.dumps(new,ensure_ascii=False),diff,iso(),previous_success_at,duration_seconds))

    async def add_availability_event(self, monitor_id, user_id, username, event_type, snapshot_id, details):
        return await self.execute(
            "INSERT INTO availability_events(monitor_id,user_id,username,event_type,snapshot_id,created_at,details_json) "
            "VALUES(?,?,?,?,?,?,?)",
            (monitor_id,user_id,username,event_type,snapshot_id,iso(),json.dumps(details,ensure_ascii=False)))

    async def add_attempt(self, monitor_id, user_id, username, state, error, duration):
        return await self.execute(
            "INSERT INTO check_attempts(monitor_id,user_id,username,state,error_code,duration_ms,checked_at) "
            "VALUES(?,?,?,?,?,?,?)", (monitor_id,user_id,username,state,error,duration,iso()))

    async def get_events(self, user_id, username=None, kind=None, limit=20, offset=0):
        clauses, args = ["user_id=?"], [user_id]
        if username: clauses.append("username=?"); args.append(username)
        if kind == "change":
            table = "change_events"
        elif kind in ("unavailable","recovered"):
            table = "availability_events"; clauses.append("event_type=?"); args.append(kind)
        else:
            table = "change_events"
        rows = await self.fetchall(f"SELECT * FROM {table} WHERE {' AND '.join(clauses)} ORDER BY created_at DESC LIMIT ? OFFSET ?",
                                   (*args,limit,offset))
        return rows

    async def setting(self, user_id):
        row = await self.fetchone("SELECT data_json FROM settings WHERE user_id=?", (user_id,))
        return json.loads(row["data_json"]) if row else {}

    async def save_setting(self, user_id, data):
        await self.execute("INSERT INTO settings(user_id,data_json,updated_at) VALUES(?,?,?) "
                           "ON CONFLICT(user_id) DO UPDATE SET data_json=excluded.data_json,updated_at=excluded.updated_at",
                           (user_id,json.dumps(data),iso()))

    async def counts(self, user_id):
        active = await self.fetchone("SELECT COUNT(*) n FROM monitors WHERE user_id=? AND state='active'",(user_id,))
        kinds = await self.fetchall("SELECT kind,COUNT(*) n FROM monitors WHERE user_id=? AND state!='stopped' GROUP BY kind",(user_id,))
        snapshots = await self.fetchone("SELECT COUNT(*) n FROM snapshots WHERE user_id=?",(user_id,))
        changes = await self.fetchone("SELECT COUNT(*) n FROM change_events WHERE user_id=?",(user_id,))
        transitions = await self.fetchone("SELECT COUNT(*) n FROM availability_events WHERE user_id=?",(user_id,))
        attempts = await self.fetchone("SELECT COUNT(*) n, SUM(CASE WHEN state='available' THEN 1 ELSE 0 END) ok, AVG(duration_ms) avg_ms, MAX(checked_at) last FROM check_attempts WHERE user_id=?",(user_id,))
        paused = await self.fetchone("SELECT COUNT(*) n FROM monitors WHERE user_id=? AND state='paused'",(user_id,))
        return {"active":active["n"],"by_kind":{r["kind"]:r["n"] for r in kinds},
                "snapshots":snapshots["n"],"changes":changes["n"],"transitions":transitions["n"],
                "attempts":attempts["n"] or 0,"successes":attempts["ok"] or 0,
                "failures":(attempts["n"] or 0)-(attempts["ok"] or 0),
                "avg_ms":round(attempts["avg_ms"] or 0),"last_check":attempts["last"],
                "paused":paused["n"]}

    async def export_user(self, user_id):
        output = {}
        for table in ("monitors","snapshots","change_events","availability_events","custom_cards","check_attempts","settings"):
            rows = await self.fetchall(f"SELECT * FROM {table} WHERE user_id=?", (user_id,))
            output[table] = [dict(r) for r in rows]
        return output

    async def delete_user_data(self, user_id):
        async with self.db.execute("BEGIN IMMEDIATE"):
            for table in ("monitors","snapshots","change_events","availability_events","custom_cards","check_attempts","settings"):
                await self.db.execute(f"DELETE FROM {table} WHERE user_id=?", (user_id,))
            await self.db.commit()
