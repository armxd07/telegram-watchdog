from datetime import datetime, timezone
from zoneinfo import ZoneInfo

def parse_ts(value):
    if not value:
        return None
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)

def format_duration(seconds):
    if seconds is None:
        return "—"
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    if seconds < 86400:
        return f"{seconds // 3600}h {(seconds % 3600) // 60}m"
    days, rem = divmod(seconds, 86400)
    return f"{days}d {rem // 3600}h {(rem % 3600) // 60}m"

def elapsed(start, end=None):
    a = parse_ts(start)
    b = parse_ts(end) if end else datetime.now(timezone.utc)
    return max(0, int((b - a).total_seconds())) if a and b else None

def display_ts(value, timezone_name="UTC"):
    dt = parse_ts(value)
    return dt.astimezone(ZoneInfo(timezone_name)).strftime("%Y-%m-%d %H:%M:%S %Z") if dt else "—"
