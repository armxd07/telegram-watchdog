import asyncio, json, logging, os, tempfile
from pathlib import Path
from telegram import Update, InputFile
from telegram.ext import (Application, CommandHandler, MessageHandler, CallbackQueryHandler,
                          ContextTypes, filters)
from .keyboards import *
from .conversations import begin, current, clear, Flow
from .validators import normalize_username, parse_interval, parse_nonnegative_int
from .models import MonitorType, Availability
from .card_renderer import save_card, fetch_avatar
from .statistics import dashboard, render_dashboard
from .event_history import history_text, export_csv
from .diffing import decode_snapshot
from .time_utils import elapsed, format_duration

log=logging.getLogger(__name__)
PAGE=8

class BotController:
    def __init__(self,db,instagram,engine,config,started_at):
        self.db,self.instagram,self.engine,self.config,self.started_at=db,instagram,engine,config,started_at

    async def show(self,update,text,reply_markup=None):
        if update.callback_query:
            msg=update.callback_query.message
            try: await msg.edit_text(text,reply_markup=reply_markup)
            except Exception: await msg.reply_text(text,reply_markup=reply_markup)
        else:
            await update.effective_message.reply_text(text,reply_markup=reply_markup)

    async def start(self,u,c):
        await self.db.ensure_user(u.effective_user.id,u.effective_chat.id)
        clear(c)
        await self.show(u,"Welcome to ARIX IG Watchdog. Choose an action below.",home())
        await u.effective_message.reply_text("Main menu",reply_markup=main_reply())

    async def home(self,u,c):
        clear(c); await self.show(u,"📍 Main menu — choose an action.",home())

    async def help(self,u,c):
        await self.show(u,"Commands: /live /monitor /banmonitor /unbanmonitor /customcard "
            "/watchlist /stats /history /duration /refresh /pause /resume /remove /settings /status /cancel\n"
            "Instagram access requires an authorized session configured by the operator. "
            "Unavailable does not necessarily mean banned.",home())

    async def begin_lookup(self,u,c,kind):
        begin(c,Flow.USERNAME,kind=kind)
        labels={"profile":"Send an Instagram username or profile URL.",
                "live":"Send username for a Live Monitor.",
                "ban":"Send username for an Availability (Ban) Monitor.",
                "unban":"Send username for a Recovery (Unban) Monitor."}
        await self.show(u,labels[kind],home())

    async def username_input(self,u,c,text):
        flow=current(c); kind=flow.get("payload",{}).get("kind")
        try: username=normalize_username(text)
        except ValueError as exc:
            await u.effective_message.reply_text(str(exc)); return
        clear(c)
        if kind=="profile":
            await self.lookup_profile(u,c,username); return
        result=await self.instagram.lookup(username)
        if result.availability==Availability.UNKNOWN:
            await self.show(u,f"Lookup unknown: {result.error_message}\nNo monitor created. Retry later.",home()); return
        if kind=="ban" and result.availability!=Availability.AVAILABLE:
            await self.show(u,"Profile is already unavailable. Use Unban Monitor for a recovery watch.",home()); return
        if kind=="unban" and result.availability==Availability.AVAILABLE:
            await self.show(u,"Profile is currently accessible. Recovery watch needs an unavailable baseline. "
                "Use Ban Monitor or confirm a recovery watch anyway.",inline([[("Confirm recovery watch","unban:force")], [("Cancel","cancel")]]))
            c.user_data["pending_username"]=username
            return
        c.user_data["pending_monitor"]={"username":username,"kind":kind,
            "snapshot":result.snapshot.normalized() if result.snapshot else None,
            "initial_unavailable": result.availability == Availability.UNAVAILABLE}
        await self.show(u,f"Verified baseline: @{username}\n"
            f"Status: {result.availability.value}\n"
            "Choose a safe interval. Unavailability is not proof of a ban.",
            inline([[("5 min","interval:300"),("15 min","interval:900"),("30 min","interval:1800")],
                    [("1 hour","interval:3600"),("Confirm","monitor:confirm")],
                    [("Cancel","cancel")]]))

    async def lookup_profile(self,u,c,username):
        await self.show(u,f"Looking up @{username}…")
        result=await self.instagram.lookup(username)
        if result.availability!=Availability.AVAILABLE or not result.snapshot:
            await self.show(u,f"Could not verify @{username}. State: {result.availability.value}\n"
                f"Reason: {result.error_message or result.error_code}\n"
                "A previous verified snapshot, if any, remains stored separately.",home()); return
        snap=result.snapshot
        avatar=await fetch_avatar(snap.profile_pic_url)
        path=f"/tmp/arix-profile-{u.effective_user.id}.png"
        save_card(snap.normalized(),path,"live",avatar)
        caption=(f"📸 @{snap.username}\n{snap.full_name}\n"
            f"Followers: {snap.followers if snap.followers is not None else '—'}\n"
            f"Following: {snap.following if snap.following is not None else '—'}\n"
            f"Posts: {snap.posts if snap.posts is not None else '—'}\n"
            f"Verified: {snap.verified if snap.verified is not None else 'unknown'} · "
            f"Private: {snap.is_private if snap.is_private is not None else 'unknown'}\n"
            f"URL: https://www.instagram.com/{snap.username}/\n"
            f"Fetched: {snap.fetched_at}\nLookup: {snap.duration_ms} ms")
        with open(path,"rb") as f:
            await u.effective_chat.send_photo(photo=f,caption=caption,reply_markup=profile_actions())
        c.user_data["last_profile"]=snap.normalized()

    async def create_monitor(self,u,c,interval):
        pending=c.user_data.get("pending_monitor")
        if not pending: await self.show(u,"Monitor setup expired. Start again.",home()); return
        kind=pending["kind"]; username=pending["username"]
        mid=await self.db.create_monitor(u.effective_user.id,u.effective_chat.id,username,kind,
                                         interval,self.config.max_monitors_per_user)
        if pending.get("snapshot"):
            from .models import ProfileSnapshot
            snap=ProfileSnapshot.from_dict(pending["snapshot"])
            sid=await self.db.save_snapshot(mid,u.effective_user.id,snap)
            await self.db.update_monitor(mid,u.effective_user.id,last_success_at=snap.fetched_at,success_count=1)
        if pending.get("initial_unavailable"):
            await self.db.update_monitor(mid,u.effective_user.id,
                first_unavailable_at=__import__("arix.models",fromlist=["iso"]).iso(),
                last_unavailable_at=__import__("arix.models",fromlist=["iso"]).iso())
        row=await self.db.get_monitor(mid,u.effective_user.id)
        self.engine.schedule(dict(row)); c.user_data.pop("pending_monitor",None)
        await self.show(u,f"✅ {kind.title()} monitor created for @{username}. ID: {mid}\n"
            f"Interval: {interval}s. Checks persist across restarts.",monitor_actions(mid,"active"))

    async def watchlist(self,u,c,page=0):
        rows=await self.db.list_monitors(u.effective_user.id,active_only=True,limit=PAGE,offset=page*PAGE)
        if not rows: await self.show(u,"Your watchlist is empty.",home()); return
        lines=["📋 Active Watchlist"]
        buttons=[]
        for row in rows:
            lines.append(f"#{row['id']} @{row['username']} · {row['kind']} · {row['state']} · {row['interval_seconds']}s")
            buttons.append([(f"@{row['username']} · {row['kind']}",f"detail:{row['id']}")])
        more=len(await self.db.list_monitors(u.effective_user.id,active_only=True,limit=PAGE+1,offset=page*PAGE))>PAGE
        nav=[]
        if page: nav.append(("⬅️ Previous",f"watch:{page-1}"))
        if more: nav.append(("Next ➡️",f"watch:{page+1}"))
        if nav: buttons.append(nav)
        buttons.append([("🏠 Home","home")])
        await self.show(u,"\n".join(lines),inline(buttons))

    async def monitor_detail(self,u,c,mid):
        row=await self.db.get_monitor(mid,u.effective_user.id)
        if not row: await self.show(u,"Monitor not found.",home()); return
        await self.show(u,f"Monitor #{mid}\n@{row['username']} · {row['kind']}\n"
            f"State: {row['state']}\nInterval: {row['interval_seconds']}s\n"
            f"Started: {row['created_at']}\nLast success: {row['last_success_at'] or '—'}\n"
            f"Successes: {row['success_count']} · Failed/unknown: {row['failure_count']}",
            monitor_actions(mid,row["state"]))

    async def dashboard(self,u,c):
        data=await dashboard(self.db,u.effective_user.id,self.started_at)
        await self.show(u,render_dashboard(data),inline([[("Refresh","stats")],
            [("Recent Events","history:0"),("Watchlist","watch:0")],[("Export CSV","stats:export")],
            [("🏠 Home","home")]]))

    async def history(self,u,c,page=0,username=None):
        text=await history_text(self.db,u.effective_user.id,username,page)
        transitions=await self.db.fetchall(
            "SELECT * FROM availability_events WHERE user_id=? ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (u.effective_user.id,PAGE,page*PAGE))
        if transitions:
            text += "\\n\\nAvailability transitions (separate from profile changes):"
            for event in transitions:
                text += f"\\n#{event['id']} @{event['username']} · {event['event_type']} · {event['created_at']}"
        await self.show(u,text,page_nav("history",page,len(transitions)>=PAGE))

    async def custom_start(self,u,c):
        c.user_data["custom"]={"username":"","full_name":"","biography":"","followers":"",
            "following":"","posts":"","event_type":"custom_live","event_timestamp":"",
            "elapsed_duration":"","footer":""}
        await self.custom_menu(u,c)

    async def custom_menu(self,u,c):
        data=c.user_data.get("custom")
        if not data: await self.custom_start(u,c); return
        lines=["🎨 Custom Card Studio — manual values only"]
        for key,value in data.items(): lines.append(f"{key}: {str(value)[:70] or '—'}")
        buttons=[]
        for key in data: buttons.append([(f"Edit {key}",f"custom:edit:{key}")])
        buttons += [[("Preview Card","custom:preview"),("Save Card","custom:save")],
                    [("Reset","custom:reset"),("Cancel","cancel")]]
        await self.show(u,"\n".join(lines),inline(buttons))

    async def custom_edit(self,u,c,key):
        if key not in c.user_data.get("custom",{}): await self.show(u,"Unknown field.",home()); return
        begin(c,Flow.CUSTOM_VALUE,key=key)
        await self.show(u,f"Send the exact value for {key}. Send /cancel to abort.",home())

    async def custom_value(self,u,c,text):
        flow=current(c); key=flow.get("payload",{}).get("key")
        if key not in c.user_data.get("custom",{}): clear(c); return
        c.user_data["custom"][key]=text
        clear(c); await self.custom_menu(u,c)

    async def custom_preview(self,u,c,save=False):
        data=c.user_data.get("custom")
        if not data: await self.show(u,"No custom card in progress.",home()); return
        path=f"/tmp/arix-custom-{u.effective_user.id}.png"
        save_card(data,path,data.get("event_type","custom_live"),custom=True)
        with open(path,"rb") as f:
            await u.effective_chat.send_photo(photo=f,caption="Custom card preview — manually entered values, not a verified Instagram event.")
        if save:
            cid=await self.db.execute("INSERT INTO custom_cards(user_id,chat_id,username,payload_json,created_at,image_path) VALUES(?,?,?,?,?,?)",
                (u.effective_user.id,u.effective_chat.id,data.get("username",""),json.dumps(data),__import__("arix.models",fromlist=["iso"]).iso(),path))
            await self.show(u,f"Custom card saved as #{cid}. It is not part of verified event history.",home())

    async def settings(self,u,c):
        await self.show(u,"⚙️ Settings — settings are scoped to your Telegram account.",settings_keyboard())

    async def time_dashboard(self,u,c):
        rows=await self.db.list_monitors(u.effective_user.id,active_only=True)
        if not rows: await self.show(u,"No active monitors.",home()); return
        lines=["⏱ Time & Duration"]
        for r in rows:
            lines.append(f"#{r['id']} @{r['username']} · age {format_duration(elapsed(r['created_at']))} · "
                f"since success {format_duration(elapsed(r['last_success_at']))} · "
                f"last lookup {r['last_duration_ms']}ms")
        await self.show(u,"\n".join(lines),home())

    async def remove_menu(self,u,c):
        await self.watchlist(u,c)

    async def text_message(self,u,c):
        flow=current(c)
        if flow.get("name")==Flow.USERNAME: await self.username_input(u,c,u.effective_message.text)
        elif flow.get("name")==Flow.CUSTOM_VALUE: await self.custom_value(u,c,u.effective_message.text)
        elif flow.get("name")==Flow.TIMEZONE:
            from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
            try:
                ZoneInfo(u.effective_message.text.strip())
                settings=await self.db.setting(u.effective_user.id)
                settings["timezone"]=u.effective_message.text.strip()
                await self.db.save_setting(u.effective_user.id,settings)
                clear(c); await self.show(u,"Timezone saved.",settings_keyboard())
            except (ZoneInfoNotFoundError,ValueError):
                await u.effective_message.reply_text("Unknown timezone. Try an IANA name such as Asia/Kolkata.")
        elif flow.get("name")==Flow.INTERVAL:
            try: interval=parse_interval(u.effective_message.text)
            except ValueError as exc: await u.effective_message.reply_text(str(exc)); return
            clear(c); await self.create_monitor(u,c,interval)
        else:
            text=u.effective_message.text
            routes={"📸 Live Profile":("lookup","profile"),"👁 Live Monitor":("lookup","live"),
                    "🚫 Ban Monitor":("lookup","ban"),"🔓 Unban Monitor":("lookup","unban"),
                    "🎨 Custom Card Studio":("custom",None),"📋 Active Watchlist":("watch",None),
                    "📊 Statistics Dashboard":("stats",None),"📜 Event History":("history",None),
                    "⏱ Time & Duration":("duration",None),"🗑 Remove Monitor":("remove",None),
                    "🔄 Refresh Data":("refresh",None),"⚙️ Settings":("settings",None),"❓ Help":("help",None)}
            action=routes.get(text)
            if action: await self.route_menu(u,c,*action)

    async def route_menu(self,u,c,action,arg=None):
        if action=="lookup": await self.begin_lookup(u,c,arg)
        elif action=="custom": await self.custom_start(u,c)
        elif action=="watch": await self.watchlist(u,c)
        elif action=="stats": await self.dashboard(u,c)
        elif action=="history": await self.history(u,c)
        elif action=="duration": await self.time_dashboard(u,c)
        elif action=="remove": await self.remove_menu(u,c)
        elif action=="refresh":
            last=c.user_data.get("last_profile")
            if last: await self.lookup_profile(u,c,last["username"])
            else: await self.show(u,"Look up a profile first or refresh a monitor from its detail screen.",home())
        elif action=="settings": await self.settings(u,c)
        elif action=="help": await self.help(u,c)

    async def callback(self,u,c):
        q=u.callback_query
        try: await q.answer()
        except Exception: pass
        data=q.data or ""
        try:
            if data=="home": await self.home(u,c)
            elif data=="cancel": clear(c); c.user_data.pop("pending_monitor",None); await self.show(u,"Cancelled.",home())
            elif data.startswith("begin:"): await self.begin_lookup(u,c,data.split(":")[1])
            elif data.startswith("interval:"):
                parts=data.split(":")
                if len(parts)==2 and parts[1].isdigit():
                    # Setup preset callback (300/900/1800/3600) versus edit-monitor callback.
                    value=int(parts[1])
                    pending=c.user_data.get("pending_monitor")
                    if pending and value in (300,900,1800,3600):
                        await self.create_monitor(u,c,value)
                    else:
                        mid=value
                        row=await self.db.get_monitor(mid,u.effective_user.id)
                        if row: await self.show(u,f"Choose interval for @{row['username']}.",inline([
                            [("5 min",f"intervalset:{mid}:300"),("15 min",f"intervalset:{mid}:900")],
                            [("30 min",f"intervalset:{mid}:1800"),("1 hour",f"intervalset:{mid}:3600")],
                            [("Cancel","cancel")]]))
                        else: await self.show(u,"Monitor not found.",home())
            elif data=="monitor:confirm":
                pending=c.user_data.get("pending_monitor")
                if pending: await self.create_monitor(u,c,self.config.check_seconds)
                else: await self.show(u,"Setup expired.",home())
            elif data=="unban:force":
                username=c.user_data.pop("pending_username",None)
                if not username: await self.show(u,"Setup expired.",home()); return
                c.user_data["pending_monitor"]={"username":username,"kind":"unban","snapshot":None}
                await self.create_monitor(u,c,self.config.check_seconds)
            elif data.startswith("watch:"): await self.watchlist(u,c,int(data.split(":")[1]))
            elif data=="remove:one": await self.watchlist(u,c)
            elif data=="remove:allask":
                await self.show(u,"Stop ALL your monitors? This cannot be undone.",confirm("removeall","all"))
            elif data=="confirm:removeall:all":
                rows=await self.db.list_monitors(u.effective_user.id,active_only=True)
                for row in rows: await self.engine.stop(row["id"],u.effective_user.id)
                await self.show(u,f"Stopped {len(rows)} monitors.",home())
            elif data.startswith("detail:"): await self.monitor_detail(u,c,int(data.split(":")[1]))
            elif data.startswith("pause:"):
                mid=int(data.split(":")[1]); await self.engine.pause(mid,u.effective_user.id); await self.monitor_detail(u,c,mid)
            elif data.startswith("resume:"):
                mid=int(data.split(":")[1]); await self.engine.resume(mid,u.effective_user.id); await self.monitor_detail(u,c,mid)
            elif data.startswith("mrefresh:"):
                mid=int(data.split(":")[1]); await self.engine.refresh(mid,u.effective_user.id); await self.monitor_detail(u,c,mid)
            elif data.startswith("intervalset:"):
                _,mid,seconds=data.split(":")
                mid,seconds=int(mid),int(seconds)
                await self.db.update_monitor(mid,u.effective_user.id,interval_seconds=seconds)
                await self.monitor_detail(u,c,mid)
            elif data.startswith("stopask:"):
                mid=int(data.split(":")[1]); await self.show(u,f"Stop monitor #{mid}?",confirm("stop",mid))
            elif data.startswith("confirm:stop:"):
                mid=int(data.split(":")[2]); await self.engine.stop(mid,u.effective_user.id); await self.show(u,f"Monitor #{mid} stopped.",home())
            elif data.startswith("snapshot:"):
                _,mid,which=data.split(":"); row=await (self.db.latest_snapshot(int(mid)) if which=="latest" else self.db.previous_snapshot(int(mid)))
                if not row or row["user_id"]!=u.effective_user.id: await self.show(u,"Snapshot unavailable.",home())
                else: await self.show(u,json.dumps(json.loads(row["data_json"]),ensure_ascii=False,indent=2)[:3800],home())
            elif data.startswith("mhist:"):
                mid=int(data.split(":")[1]); row=await self.db.get_monitor(mid,u.effective_user.id)
                if not row: await self.show(u,"Monitor not found.",home())
                else: await self.show(u,await history_text(self.db,u.effective_user.id,row["username"]),home())
            elif data=="profile:bio":
                bio=c.user_data.get("last_profile",{}).get("biography","")
                await self.show(u,bio or "No biography returned.",home())
            elif data=="profile:refresh":
                last=c.user_data.get("last_profile")
                if last: await self.lookup_profile(u,c,last["username"])
                else: await self.show(u,"No profile to refresh.",home())
            elif data=="custom:start": await self.custom_start(u,c)
            elif data.startswith("custom:edit:"): await self.custom_edit(u,c,data.split(":",2)[2])
            elif data=="custom:preview": await self.custom_preview(u,c)
            elif data=="custom:save": await self.custom_preview(u,c,True)
            elif data=="custom:reset": await self.custom_start(u,c)
            elif data=="stats": await self.dashboard(u,c)
            elif data=="stats:export":
                csv_data=await export_csv(self.db,u.effective_user.id)
                path=f"/tmp/arix-events-{u.effective_user.id}.csv"
                Path(path).write_text(csv_data,encoding="utf-8")
                with open(path,"rb") as f: await u.effective_chat.send_document(f,filename="arix-events.csv")
            elif data.startswith("history:"): await self.history(u,c,int(data.split(":")[1]))
            elif data=="setting:pauseall":
                rows=await self.db.list_monitors(u.effective_user.id,active_only=True)
                for r in rows: await self.engine.pause(r["id"],u.effective_user.id)
                await self.show(u,f"Paused {len(rows)} monitors.",home())
            elif data=="setting:resumeall":
                rows=await self.db.list_monitors(u.effective_user.id)
                for r in rows:
                    if r["state"]=="paused": await self.engine.resume(r["id"],u.effective_user.id)
                await self.show(u,"Paused monitors resumed.",home())
            elif data=="setting:interval":
                await self.show(u,"Choose your default monitor interval.",inline([
                    [("5 min","setting:setinterval:300"),("15 min","setting:setinterval:900")],
                    [("30 min","setting:setinterval:1800"),("1 hour","setting:setinterval:3600")],
                    [("Back","settings")]]))
            elif data.startswith("setting:setinterval:"):
                seconds=int(data.rsplit(":",1)[1])
                settings=await self.db.setting(u.effective_user.id); settings["default_interval"]=seconds
                await self.db.save_setting(u.effective_user.id,settings)
                await self.show(u,f"Default interval saved: {seconds}s.",settings_keyboard())
            elif data=="setting:notifications":
                settings=await self.db.setting(u.effective_user.id)
                settings["notifications"]=not settings.get("notifications",True)
                await self.db.save_setting(u.effective_user.id,settings)
                await self.show(u,f"Notifications: {'on' if settings['notifications'] else 'off'}.",settings_keyboard())
            elif data=="setting:timezone":
                begin(c,Flow.TIMEZONE)
                await self.show(u,"Send an IANA timezone, e.g. Asia/Kolkata or UTC.",home())
            elif data=="setting:card":
                settings=await self.db.setting(u.effective_user.id)
                settings["card_style"]="midnight-blue" if settings.get("card_style")!="midnight-blue" else "classic"
                await self.db.save_setting(u.effective_user.id,settings)
                await self.show(u,f"Card style: {settings['card_style']}.",settings_keyboard())
            elif data=="setting:session":
                await self.show(u,"Instagram session: "+("configured" if self.instagram.client else "not configured"),home())
            elif data=="setting:status":
                await self.show(u,f"Application running. Polling floor: {self.config.check_seconds}s.",home())
            elif data=="setting:deleteask":
                await self.show(u,"Delete all your monitoring data? This cannot be undone.",confirm("delete",u.effective_user.id))
            elif data.startswith("confirm:delete:"):
                await self.engine.shutdown()
                await self.db.delete_user_data(u.effective_user.id)
                await self.show(u,"Your monitoring data was deleted. Restart the bot's monitor scheduler to resume other users.",home())
            elif data=="setting:export":
                data_json=json.dumps(await self.db.export_user(u.effective_user.id),ensure_ascii=False,indent=2)
                path=f"/tmp/arix-export-{u.effective_user.id}.json"; Path(path).write_text(data_json)
                with open(path,"rb") as f: await u.effective_chat.send_document(f,filename="arix-data-export.json")
            elif data.startswith("setting:"):
                await self.show(u,"This setting is not configurable in this release; current server defaults remain enforced.",settings_keyboard())
            else: await self.show(u,"That action expired. Open the menu and try again.",home())
        except Exception as exc:
            log.exception("Callback failed")
            await self.show(u,f"Action failed safely: {str(exc)[:180]}",home())

    async def command(self,u,c):
        name=u.effective_message.text.split()[0].split("@")[0][1:]
        args=u.effective_message.text.split()[1:]
        mapping={"start":lambda:self.start(u,c),"menu":lambda:self.home(u,c),
            "live":lambda:self.begin_lookup(u,c,"profile"),"monitor":lambda:self.begin_lookup(u,c,"live"),
            "banmonitor":lambda:self.begin_lookup(u,c,"ban"),"unbanmonitor":lambda:self.begin_lookup(u,c,"unban"),
            "customcard":lambda:self.custom_start(u,c),"watchlist":lambda:self.watchlist(u,c),
            "stats":lambda:self.dashboard(u,c),"history":lambda:self.history(u,c),
            "duration":lambda:self.time_dashboard(u,c),"settings":lambda:self.settings(u,c),
            "help":lambda:self.help(u,c),"remove":lambda:self.remove_menu(u,c),
            "refresh":lambda:self.watchlist(u,c)}
        if name=="cancel":
            clear(c); await self.show(u,"Cancelled.",home()); return
        if name in ("pause","resume","refresh") and not args:
            await self.watchlist(u,c); return
        if name in ("pause","resume","refresh") and args:
            try:
                mid=int(args[0])
                if name=="pause": await self.engine.pause(mid,u.effective_user.id)
                elif name=="resume": await self.engine.resume(mid,u.effective_user.id)
                else: await self.engine.refresh(mid,u.effective_user.id)
                await self.monitor_detail(u,c,mid)
            except Exception as exc: await self.show(u,str(exc),home())
            return
        if name=="status":
            await self.show(u,f"Running. DB: {self.config.database_path}. Instagram session: "
                f"{'configured' if self.instagram.client else 'not configured'}.",home()); return
        fn=mapping.get(name)
        if fn: await fn()
        else: await self.help(u,c)

def register_handlers(app, controller):
    async def command_dispatch(update,context): await controller.command(update,context)
    async def callback_dispatch(update,context): await controller.callback(update,context)
    async def text_dispatch(update,context): await controller.text_message(update,context)
    commands=["start","menu","live","monitor","banmonitor","unbanmonitor","customcard",
              "watchlist","stats","history","duration","refresh","pause","resume","remove",
              "settings","status","help","cancel"]
    app.add_handler(CallbackQueryHandler(callback_dispatch))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_dispatch))
    for command in commands: app.add_handler(CommandHandler(command,command_dispatch))
