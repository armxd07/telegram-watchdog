from dataclasses import dataclass
from pathlib import Path
import os
from dotenv import load_dotenv

@dataclass(frozen=True)
class Config:
    telegram_bot_token: str
    database_path: str
    ig_sessionid: str
    ig_settings_path: str
    check_seconds: int
    max_monitors_per_user: int
    log_level: str
    timezone: str
    ig_request_timeout: int
    ig_min_request_gap: int

    @classmethod
    def from_env(cls):
        load_dotenv()
        token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        if not token:
            raise RuntimeError("TELEGRAM_BOT_TOKEN is required")
        return cls(
            telegram_bot_token=token,
            database_path=os.getenv("DATABASE_PATH", "./data/arix.sqlite3"),
            ig_sessionid=os.getenv("IG_SESSIONID", ""),
            ig_settings_path=os.getenv("IG_SETTINGS_PATH", "./data/instagram_settings.json"),
            check_seconds=max(300, int(os.getenv("CHECK_SECONDS", "900"))),
            max_monitors_per_user=max(1, int(os.getenv("MAX_MONITORS_PER_USER", "10"))),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
            timezone=os.getenv("TIMEZONE", "UTC"),
            ig_request_timeout=max(5, int(os.getenv("IG_REQUEST_TIMEOUT", "25"))),
            ig_min_request_gap=max(5, int(os.getenv("IG_MIN_REQUEST_GAP", "30"))),
        )

    def ensure_paths(self):
        Path(self.database_path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
        Path(self.ig_settings_path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
