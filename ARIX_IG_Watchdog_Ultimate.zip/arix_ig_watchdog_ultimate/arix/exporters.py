"""Serialization helpers for user-requested data exports."""
import csv, io, json
from datetime import datetime, timezone

def json_export(data):
    return json.dumps(data,ensure_ascii=False,indent=2,default=str)

def csv_rows(headers, rows):
    stream=io.StringIO(newline="")
    writer=csv.writer(stream)
    writer.writerow(headers)
    writer.writerows(rows)
    return stream.getvalue()

def redact_runtime_settings(settings):
    forbidden={"token","password","sessionid","cookie","secret"}
    return {k:("[REDACTED]" if any(x in k.lower() for x in forbidden) else v)
            for k,v in settings.items()}
