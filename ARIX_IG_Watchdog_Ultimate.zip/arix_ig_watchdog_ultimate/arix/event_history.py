import csv, io, json
async def history_text(db,user_id,username=None,page=0,page_size=10):
    rows=await db.get_events(user_id,username,limit=page_size,offset=page*page_size)
    if not rows: return "No verified profile-change events found."
    lines=["📜 Verified profile change history"]
    for r in rows:
        lines.append(f"#{r['id']} @{r['username']} · {r['field']} · {r['old_value']} → {r['new_value']} · {r['created_at']}")
    return "\n".join(lines)

async def export_csv(db,user_id):
    output=io.StringIO()
    writer=csv.writer(output)
    writer.writerow(["id","username","field","old_value","new_value","difference","created_at"])
    rows=await db.fetchall("SELECT * FROM change_events WHERE user_id=? ORDER BY created_at DESC",(user_id,))
    for r in rows:
        writer.writerow([r["id"],r["username"],r["field"],r["old_value"],r["new_value"],r["difference"],r["created_at"]])
    return output.getvalue()
