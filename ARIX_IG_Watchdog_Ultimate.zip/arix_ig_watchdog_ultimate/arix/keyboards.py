from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup

MAIN_ROWS=[
 ["📸 Live Profile","👁 Live Monitor"],
 ["🚫 Ban Monitor","🔓 Unban Monitor"],
 ["🎨 Custom Card Studio","📋 Active Watchlist"],
 ["📊 Statistics Dashboard","📜 Event History"],
 ["⏱ Time & Duration","🗑 Remove Monitor"],
 ["🔄 Refresh Data","⚙️ Settings"],
 ["❓ Help"],
]
def main_reply():
    return ReplyKeyboardMarkup(MAIN_ROWS,resize_keyboard=True,persistent=True)

def inline(rows):
    return InlineKeyboardMarkup([[InlineKeyboardButton(text,callback_data=data) for text,data in row] for row in rows])

def home():
    return inline([[("🏠 Home","home"),("❌ Cancel","cancel")]])

def profile_actions():
    return inline([[("🔄 Refresh","profile:refresh"),("👁 Live Monitor","begin:live")],
                   [("🚫 Ban Monitor","begin:ban"),("🔓 Unban Monitor","begin:unban")],
                   [("🎨 Custom Card","custom:start"),("📖 Full Biography","profile:bio")],
                   [("🏠 Menu","home")]])

def monitor_actions(mid,state):
    toggle=("Pause","pause") if state=="active" else ("Resume","resume")
    return inline([[("Refresh Now",f"mrefresh:{mid}"),(toggle[0],f"{toggle[1]}:{mid}")],
                   [("Latest Snapshot",f"snapshot:{mid}:latest"),("Previous",f"snapshot:{mid}:previous")],
                   [("Change Interval",f"interval:{mid}"),("History",f"mhist:{mid}:0")],
                   [("Stop Monitor",f"stopask:{mid}"),("Back","watch:0")]])

def page_nav(prefix,page,has_next):
    row=[]
    if page>0: row.append(("⬅️ Previous",f"{prefix}:{page-1}"))
    if has_next: row.append(("Next ➡️",f"{prefix}:{page+1}"))
    return inline([row,[("🏠 Home","home")]])

def confirm(action,identifier):
    return inline([[("✅ Confirm",f"confirm:{action}:{identifier}"),("Cancel","cancel")],
                   [("🏠 Home","home")]])

def settings_keyboard():
    return inline([[("Interval presets","setting:interval"),("Notifications","setting:notifications")],
                   [("Timezone","setting:timezone"),("Card style","setting:card")],
                   [("Pause all","setting:pauseall"),("Resume all","setting:resumeall")],
                   [("Export my data","setting:export"),("Delete my data","setting:deleteask")],
                   [("Session status","setting:session"),("App status","setting:status")],
                   [("🏠 Home","home")]])
