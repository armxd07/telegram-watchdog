"""Polling policy helpers. Conservative defaults reduce accidental request bursts."""
import random

def next_delay(base_seconds, consecutive_failures=0, ceiling=21600, jitter=0.15):
    base=max(300,int(base_seconds))
    exponent=min(max(0,int(consecutive_failures)),8)
    delay=min(ceiling,base*(2**exponent))
    spread=delay*jitter
    return max(300,int(delay+random.uniform(-spread,spread)))

def can_poll(last_attempt_epoch, now_epoch, minimum_gap):
    if last_attempt_epoch is None:
        return True
    return now_epoch-last_attempt_epoch >= minimum_gap

def normalize_interval(value):
    return min(86400,max(300,int(value)))
