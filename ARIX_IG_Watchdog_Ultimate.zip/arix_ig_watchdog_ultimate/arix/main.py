import asyncio, logging, time
from telegram.ext import Application
from .config import Config
from .database import Database
from .instagram_service import InstagramService
from .monitoring_engine import MonitoringEngine
from .scheduler import Scheduler
from .telegram_handlers import BotController, register_handlers
from .keyboards import main_reply
from .logging_config import configure_logging

async def run():
    config=Config.from_env(); config.ensure_paths()
    configure_logging(config.log_level)
    db=await Database(config.database_path).open()
    instagram=InstagramService(config)
    try: await instagram.start()
    except Exception as exc:
        logging.getLogger(__name__).warning("Instagram session initialization failed: %s",type(exc).__name__)
    app=Application.builder().token(config.telegram_bot_token).build()
    engine=MonitoringEngine(db,instagram,app.bot,config)
    controller=BotController(db,instagram,engine,config,time.time())
    register_handlers(app,controller)
    async with app:
        await app.start()
        await app.updater.start_polling(allowed_updates=["message","callback_query"])
        scheduler=Scheduler(engine); await scheduler.start()
        try:
            await asyncio.Event().wait()
        finally:
            await scheduler.stop()
            await app.updater.stop()
            await app.stop()
            await instagram.close()
            await db.close()

def main():
    asyncio.run(run())
