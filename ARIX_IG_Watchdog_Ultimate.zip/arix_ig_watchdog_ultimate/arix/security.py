import json, os, tempfile
from pathlib import Path

def private_write(path, content):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(dir=path.parent,prefix=".tmp-")
    try:
        if os.name!="nt": os.fchmod(fd,0o600)
        with os.fdopen(fd,"w",encoding="utf-8") as stream: stream.write(content)
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def safe_json(data):
    return json.dumps(data,ensure_ascii=False,indent=2,default=str)
