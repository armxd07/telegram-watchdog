"""Telegram port of the uploaded IG WATCHDOG bot.
Real profile data is shown only when verified. Demo cards are clearly labelled.
Never send IG_SESSIONID to Telegram; configure it privately in .env.
"""
import os, re, io, json, time, asyncio, logging
from datetime import datetime, timezone
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters
from PIL import Image, ImageDraw, ImageFont

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger('ig-watchdog-tg')
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
IG_SESSIONID = os.getenv('IG_SESSIONID', '').strip()
CHECK_SECONDS = max(60, int(os.getenv('CHECK_SECONDS', '120')))
STORE_PATH = 'telegram_watchlist.json'
SESSION_SETTINGS = 'ig_login_settings.json'
IG_CLIENT = None
STARTED = time.time()

# Keep the uploaded bot's main groups and names; Telegram buttons call these same actions.
MENU = [
    [('📸 Instagram Profile', 'profile'), ('🔎 IG Check', 'igcheck')],
    [('♻️ Unban Monitor', 'unban'), ('🚫 Ban Monitor', 'ban')],
    [('📈 Profile Monitor', 'monitor'), ('🧾 Watchlist', 'list')],
    [('🧪 Fake Unban / Demo', 'fakeunban'), ('🧪 Mock Profile', 'mock')],
    [('🧹 Clear Monitor', 'clear'), ('📊 Stats', 'stats')],
    [('📡 Status', 'status'), ('❔ Help', 'help')],
]

def kb():
    return InlineKeyboardMarkup([[InlineKeyboardButton(t, callback_data='menu:'+c) for t,c in row] for row in MENU])

def clean(u):
    u=(u or '').strip().strip('<>').lower()
    u=re.sub(r'^https?://(www\.)?', '', u)
    if u.startswith('instagram.com/'): u=u[len('instagram.com/'):]
    return u.lstrip('@').split('?')[0].split('/')[0].strip()

def valid(u): return bool(re.fullmatch(r'[a-z0-9._]{1,30}', u or ''))

def load_store():
    try:
        with open(STORE_PATH, encoding='utf-8') as f: d=json.load(f)
        if isinstance(d, dict): return d
    except (OSError, ValueError): pass
    return {'unban': {}, 'ban': {}, 'monitor': {}, 'demo': {}}
STORE=load_store()
def save_store():
    tmp=STORE_PATH+'.tmp'
    with open(tmp,'w',encoding='utf-8') as f: json.dump(STORE,f,indent=2,ensure_ascii=False)
    os.replace(tmp,STORE_PATH)

async def login_instagram():
    global IG_CLIENT
    if not IG_SESSIONID:
        log.info('IG_SESSIONID not configured; profile lookup may be unavailable.')
        return
    try:
        from instagrapi import Client
        def do_login():
            c=Client(); c.delay_range=[2,5]
            if os.path.exists(SESSION_SETTINGS):
                try: c.load_settings(SESSION_SETTINGS)
                except Exception: pass
            c.login_by_sessionid(IG_SESSIONID)
            try: c.dump_settings(SESSION_SETTINGS)
            except Exception: pass
            return c
        IG_CLIENT=await asyncio.to_thread(do_login)
        log.info('Instagram session accepted.')
    except Exception as e:
        # Never log the cookie or raw exception content.
        log.warning('Instagram session login failed (%s).', type(e).__name__)

def normalize_user(obj):
    if isinstance(obj, dict): return obj
    if hasattr(obj,'model_dump'): return obj.model_dump()
    if hasattr(obj,'dict') and callable(obj.dict): return obj.dict()
    if hasattr(obj,'__dict__'): return vars(obj)
    return {k:getattr(obj,k,None) for k in ('username','full_name','biography','follower_count','following_count','media_count','is_private','is_verified','profile_pic_url_hd','profile_pic_url')}

async def profile_lookup(username):
    username=clean(username)
    if not valid(username): return {'state':'error','username':username,'reason':'invalid_username'}
    if IG_CLIENT is None: return {'state':'error','username':username,'reason':'session_not_configured_or_login_failed'}
    try:
        raw=await asyncio.to_thread(IG_CLIENT.user_info_by_username_v1, username)
        u=normalize_user(raw)
        followers,following,posts=u.get('follower_count'),u.get('following_count'),u.get('media_count')
        if str(u.get('username') or '').lower()!=username: return {'state':'error','username':username,'reason':'username_mismatch'}
        if not all(isinstance(x,int) and x>=0 for x in (followers,following,posts)):
            return {'state':'error','username':username,'reason':'profile_counts_missing'}
        return {'state':'ok','username':username,'full_name':u.get('full_name') or '', 'biography':u.get('biography') or '',
                'followers':followers,'following':following,'posts':posts,'is_private':bool(u.get('is_private')),
                'is_verified':bool(u.get('is_verified')),'pic_url':str(u.get('profile_pic_url_hd') or u.get('profile_pic_url') or ''),'fetched_at':int(time.time())}
    except Exception as e:
        reason=type(e).__name__
        if any(s in str(e).lower() for s in ('429','rate limit','too many','feedback_required')): reason='rate_limited'
        return {'state':'error','username':username,'reason':reason}

async def fetch_avatar(url):
    if not url: return None
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
                return await r.read() if r.status==200 else None
    except Exception: return None

def profile_text(p, title='Instagram Profile'):
    return (f"{title}\n@{p['username']}\n\nName: {p.get('full_name') or 'Not available'}\n"
            f"Followers: {p['followers']:,}\nFollowing: {p['following']:,}\nPosts: {p['posts']:,}\n"
            f"Bio: {p.get('biography') or 'Not available'}\n\nLIVE DATA · fetched {datetime.fromtimestamp(p.get('fetched_at',int(time.time())),timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")

async def send_profile(chat, p, title='Instagram Profile'):
    text=profile_text(p,title)
    avatar=await fetch_avatar(p.get('pic_url'))
    if avatar:
        try:
            await chat.send_photo(photo=io.BytesIO(avatar), caption=text[:1024], reply_markup=kb())
            return
        except Exception: pass
    await chat.send_message(text, reply_markup=kb())

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text('IG WATCHDOG · Telegram\nChoose a command below. Live stats appear only when Instagram data is verified.', reply_markup=kb())

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text('Commands: /profile username · /igcheck username · /unban username · /ban username · /monitor username · /list · /clear username|all · /mock · /fakeunban · /stats · /status\n\nSession IDs are secrets: set IG_SESSIONID in your private .env file, never in chat.', reply_markup=kb())

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uptime=int(time.time()-STARTED)
    await update.effective_message.reply_text(f'Bot: online\nUptime: {uptime//3600}h {(uptime%3600)//60}m\nInstagram session: {"configured" if IG_CLIENT else "not verified"}\nMonitor interval: {CHECK_SECONDS}s',reply_markup=kb())

async def profile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        context.user_data['awaiting']='profile'; await update.effective_message.reply_text('Send the Instagram username (without password/session ID).'); return
    await do_profile(update.effective_chat, context.args[0])

async def do_profile(chat, username):
    p=await profile_lookup(username)
    if p['state']=='ok': await send_profile(chat,p); return
    await chat.send_message(f"Instagram data could not be verified for @{clean(username)}.\nReason: {p.get('reason')}\nThis is NOT proof of a ban.",reply_markup=kb())

async def igcheck_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        context.user_data['awaiting']='igcheck'; await update.effective_message.reply_text('Send a public Instagram username to check the configured session.'); return
    p=await profile_lookup(context.args[0])
    await update.effective_message.reply_text(f"Session status: {'accepted for profile lookup' if p['state']=='ok' else 'unverified / lookup failed'}\nResult: {p['state']}\nReason: {p.get('reason','profile data verified')}\nCookie is never displayed.",reply_markup=kb())

async def watch_cmd(update, context, kind):
    args = context.args or context.user_data.pop('pending_args', [])
    if not args:
        context.user_data['awaiting']=kind; await update.effective_message.reply_text(f'Send username(s) to start {kind} monitoring.'); return
    names=[]
    for arg in args:
        for x in arg.replace(',',' ').split():
            u=clean(x)
            if valid(u) and u not in names: names.append(u)
    if not names:
        await update.effective_message.reply_text('No valid usernames found.'); return
    added=[]
    for u in names:
        p=await profile_lookup(u)
        if kind=='unban':
            # Only begin recovery watch when unavailable was actually verified; otherwise report unknown.
            if p['state']=='error': continue
            if p['state']=='ok':
                STORE['unban'][u]={'added_at':int(time.time()),'last_state':'ok','known':p,'chat_id':update.effective_chat.id,'user_id':update.effective_user.id}
            added.append(u)
        elif kind=='ban':
            if p['state']!='ok': continue
            STORE['ban'][u]={'added_at':int(time.time()),'last_state':'ok','known':p,'chat_id':update.effective_chat.id,'user_id':update.effective_user.id}
            added.append(u)
        elif kind=='monitor':
            if p['state']!='ok': continue
            STORE['monitor'][u]={'added_at':int(time.time()),'known':p,'chat_id':update.effective_chat.id,'user_id':update.effective_user.id}
            added.append(u)
    save_store()
    if kind=='unban': msg='Recovery watch saved for verified lookups; already-live profiles will alert only if a confirmed unavailable→available transition is observed.'
    elif kind=='ban': msg='Availability watch saved for verified profiles.'
    else: msg='Profile monitor saved; future changes will be compared against verified data.'
    await update.effective_message.reply_text(msg+'\nAdded: '+(', '.join('@'+x for x in added) if added else 'none (Instagram data was not verifiable).')+'\nLookup errors are not ban evidence.',reply_markup=kb())

async def unban_cmd(update, context): await watch_cmd(update,context,'unban')
async def ban_cmd(update, context): await watch_cmd(update,context,'ban')
async def monitor_cmd(update, context): await watch_cmd(update,context,'monitor')

async def list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines=[]
    for kind in ('unban','ban','monitor'):
        lines.append(kind.upper()+': '+(', '.join('@'+u for u in STORE[kind]) or 'empty'))
    await update.effective_message.reply_text('\n'.join(lines),reply_markup=kb())

async def clear_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args or context.user_data.pop('pending_args', [])
    if not args:
        context.user_data['awaiting']='clear'; await update.effective_message.reply_text('Send a username or “all” to stop monitoring.'); return
    target=clean(args[0]); removed=0
    for kind in ('unban','ban','monitor'):
        keys=list(STORE[kind]) if target=='all' else [target]
        for u in keys:
            if u in STORE[kind]: del STORE[kind][u]; removed+=1
    save_store(); await update.effective_message.reply_text(f'Stopped {removed} monitor(s).',reply_markup=kb())

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(f"Recovery watch: {len(STORE['unban'])}\nAvailability watch: {len(STORE['ban'])}\nProfile monitor: {len(STORE['monitor'])}",reply_markup=kb())

async def demo_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE, mode='fakeunban'):
    context.user_data['demo']={'mode':mode,'step':'username','fields':{}}
    await update.effective_message.reply_text('DEMO PREVIEW ONLY — this will not unban or change any Instagram account.\nSend demo username:')

async def fakeunban_cmd(update, context): await demo_wizard(update,context,'fakeunban')
async def mock_cmd(update, context): await demo_wizard(update,context,'mock')

async def render_demo(chat, fields, mode):
    # Honest watermark; user-supplied sample fields are never represented as live Instagram data.
    w,h=1000,440; im=Image.new('RGB',(w,h),(12,14,18)); d=ImageDraw.Draw(im)
    try: f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',26); fb=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',38)
    except Exception: f=fb=ImageFont.load_default()
    d.text((40,30),'IG WATCHDOG · DEMO PREVIEW',font=fb,fill=(245,245,245))
    d.text((40,100),'@'+fields.get('username','demo'),font=fb,fill=(245,245,245))
    if fields.get('pfp_bytes'):
        try:
            av=Image.open(io.BytesIO(fields['pfp_bytes'])).convert('RGB').resize((100,100))
            im.paste(av,(850,95))
        except Exception: pass
    d.text((40,165),'Name: '+fields.get('name',''),font=f,fill=(210,210,210))
    d.text((40,210),'Bio: '+fields.get('bio','')[:90],font=f,fill=(180,180,180))
    d.text((40,270),'Posts: '+fields.get('posts','0')+'   Followers: '+fields.get('followers','0')+'   Following: '+fields.get('following','0'),font=f,fill=(245,245,245))
    d.text((40,370),'SIMULATED DATA — NOT A REAL PROFILE OR UNBAN',font=fb,fill=(255,190,90))
    out=io.BytesIO(); im.save(out,format='PNG'); out.seek(0)
    await chat.send_photo(out,caption='Demo only · no Instagram changes made.',reply_markup=kb())

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text=(update.effective_message.text or '').strip()
    awaiting=context.user_data.get('awaiting')
    if awaiting:
        context.user_data.pop('awaiting',None)
        if awaiting in ('profile','igcheck'):
            if awaiting=='profile': await do_profile(update.effective_chat,text)
            else:
                p=await profile_lookup(text); await update.effective_message.reply_text(f"Lookup: {p['state']}\nReason: {p.get('reason','verified')}",reply_markup=kb())
        elif awaiting in ('unban','ban','monitor'):
            context.user_data['pending_args']=text.replace(',',' ').split(); await watch_cmd(update,context,awaiting)
        elif awaiting=='clear':
            context.user_data['pending_args']=[text]; await clear_cmd(update,context)
        return
    demo=context.user_data.get('demo')
    if demo:
        f=demo['fields']; step=demo['step']
        if step == 'username':
            f['username']=text[:30].lstrip('@'); demo['step']='pfp'
            await update.effective_message.reply_text('Send the profile photo you want on this DEMO card, or type skip:')
            return
        if step == 'pfp':
            if text.lower() != 'skip':
                await update.effective_message.reply_text('Send a photo or type skip to continue.')
                return
            demo['step']='name'; await update.effective_message.reply_text('Send display name:'); return
        keys=['name','bio','posts','followers','following']
        f[step]=text[:180]
        idx=keys.index(step)+1
        if idx<len(keys):
            demo['step']=keys[idx]
            await update.effective_message.reply_text({'bio':'Send bio:','posts':'Send post count:','followers':'Send follower count:','following':'Send following count:'}.get(keys[idx],'Send '+keys[idx]+':'))
        else:
            context.user_data.pop('demo',None); await render_demo(update.effective_chat,f,demo['mode'])
        return
    await update.effective_message.reply_text('Use a button below or /help.',reply_markup=kb())

async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    demo=context.user_data.get('demo')
    if not demo or demo.get('step')!='pfp':
        await update.effective_message.reply_text('Photo received. Use the Demo button if you want to place it on a labelled preview.', reply_markup=kb()); return
    photo=update.effective_message.photo[-1]
    file=await context.bot.get_file(photo.file_id)
    data=await file.download_as_bytearray()
    demo['fields']['pfp_bytes']=bytes(data)
    demo['step']='name'
    await update.effective_message.reply_text('Photo added to DEMO preview. Send display name:')

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer(); action=q.data.split(':',1)[1]
    # Buttons call the same handlers as slash commands.
    if action=='profile': await q.message.reply_text('Send /profile username or just send a username after this prompt.'); context.user_data['awaiting']='profile'
    elif action=='igcheck': await q.message.reply_text('Send an Instagram username to check.'); context.user_data['awaiting']='igcheck'
    elif action in ('unban','ban','monitor'): context.user_data['awaiting']=action; await q.message.reply_text('Send username(s), separated by spaces.')
    elif action=='list': await list_cmd(update,context)
    elif action=='clear': context.user_data['awaiting']='clear'; await q.message.reply_text('Send a username or “all”.')
    elif action=='stats': await stats_cmd(update,context)
    elif action=='status': await status_cmd(update,context)
    elif action=='help': await help_cmd(update,context)
    elif action=='fakeunban': await demo_wizard(update,context,'fakeunban')
    elif action=='mock': await demo_wizard(update,context,'mock')

async def monitor_loop(app: Application):
    while True:
        await asyncio.sleep(CHECK_SECONDS)
        for kind in ('unban','ban','monitor'):
            for username,rec in list(STORE[kind].items()):
                p=await profile_lookup(username)
                if p['state']!='ok': continue
                old=rec.get('known') or {}
                if kind=='unban' and rec.get('last_state')=='down':
                    await app.bot.send_message(rec['chat_id'],f'♻️ @{username} is accessible again (verified live profile).')
                elif kind=='ban' and rec.get('last_state')=='ok' and p['state']=='not_found':
                    await app.bot.send_message(rec['chat_id'],f'Profile @{username} is reported unavailable. This may mean banned, deleted or renamed.')
                elif kind=='monitor' and old and any(old.get(k)!=p.get(k) for k in ('full_name','biography','followers','following','posts')):
                    await app.bot.send_message(rec['chat_id'],f'📈 Verified profile change: @{username}\nFollowers: {old.get("followers")} → {p.get("followers")}\nFollowing: {old.get("following")} → {p.get("following")}\nPosts: {old.get("posts")} → {p.get("posts")}')
                rec['known']=p; rec['last_state']='ok'; STORE[kind][username]=rec
        save_store()

async def post_init(app):
    await login_instagram()
    app.create_task(monitor_loop(app))

def main():
    if not BOT_TOKEN: raise SystemExit('Missing TELEGRAM_BOT_TOKEN in .env')
    app=Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler('start',start)); app.add_handler(CommandHandler('help',help_cmd))
    app.add_handler(CommandHandler('profile',profile_cmd)); app.add_handler(CommandHandler('igcheck',igcheck_cmd))
    app.add_handler(CommandHandler('unban',unban_cmd)); app.add_handler(CommandHandler('ban',ban_cmd))
    app.add_handler(CommandHandler('monitor',monitor_cmd)); app.add_handler(CommandHandler('list',list_cmd))
    app.add_handler(CommandHandler('clear',clear_cmd)); app.add_handler(CommandHandler('stats',stats_cmd)); app.add_handler(CommandHandler('status',status_cmd))
    app.add_handler(CommandHandler('fakeunban',fakeunban_cmd)); app.add_handler(CommandHandler('mock',mock_cmd))
    app.add_handler(CallbackQueryHandler(menu_callback,pattern=r'^menu:'))
    app.add_handler(MessageHandler(filters.PHOTO, photo_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    app.run_polling()
if __name__=='__main__': main()
